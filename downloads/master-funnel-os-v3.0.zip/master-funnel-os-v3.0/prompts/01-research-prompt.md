# PROMPT: NGHIÊN CỨU THỊ TRƯỜNG & PAIN POINTS

Dán prompt sau cho AI Agent để bắt đầu nghiên cứu:

```text
[VAI TRÒ]: Senior Market Research & Conversion Strategist
[NGỮ CẢNH]: Sản phẩm: [Tên Sản Phẩm/Dịch Vụ]. Khách hàng mục tiêu: [Mô tả ngắn về khách hàng].
[NHIỆM VỤ]:
1. Phân tích 5 nỗi đau sâu sắc nhất (Pain Points) khiến họ mất tiền hoặc tốn thời gian.
2. Xác định 5 kết quả lý tưởng (Dream Outcomes) mà họ khao khát nhất.
3. Liệt kê 3 lý do vì sao họ từng thử giải pháp khác nhưng thất bại.
4. Đề xuất 1 Hook thông điệp chính và 1 Cơ chế độc quyền (Unique Mechanism) cho sản phẩm.
[YÊU CẦU ĐẦU RA]: Bảng markdown rõ ràng, không dùng lời dẫn sáo rỗng.
```
