# PROMPT: BIÊN SOẠN NỘI DUNG 10 SECTIONS

Dán prompt sau cùng file `Offer-Stack.md` cho AI Agent:

```text
[VAI TRÒ]: Direct-Response Copywriter chuyên sâu về Sale Funnel
[TÀI LIỆU THAM KHẢO]: Đọc kỹ Offer-Stack.md và Design.md đính kèm.
[NHIỆM VỤ]: Viết toàn bộ nội dung 10 Sections theo đúng cấu trúc templates/10-Sections-Copy.template.md.
[QUY TẮC NỘI DUNG]:
- Viết văn phong sắc bén, thuyết phục, tập trung vào giá trị chuyển đổi.
- Tuyệt đối không dùng các từ sáo rỗng (thần thánh, tuyệt đỉnh, siêu phẩm).
- Định dạng sẵn các gạch đầu dòng và tiêu đề H1, H2, H3 rõ ràng.
```
