# PROMPT: SINH MÃ NGUỒN HTML/TAILWIND CSS

Dán prompt sau cùng file `Design.md` và đoạn copy của Section:

```text
[VAI TRÒ]: Senior Frontend Tailwind Developer
[TÀI LIỆU THAM KHẢO]: Tuân thủ nghiêm ngặt bảng màu và typography trong Design.md.
[NHIỆM VỤ]: Chuyển đoạn nội dung sau thành mã nguồn HTML/Tailwind CSS chuẩn responsive:
[DÁN ĐOẠN COPY CỦA SECTION VÀO ĐÂY]
[QUY TẮC MÃ NGUỒN]:
- Chỉ dùng utility classes chuẩn của Tailwind CSS v3/v4.
- Thiết kế Mobile-first, đảm bảo không tràn ngang trên màn hình nhỏ.
- Màu sắc và khoảng cách padding phải khớp 100% với Design.md.
```
