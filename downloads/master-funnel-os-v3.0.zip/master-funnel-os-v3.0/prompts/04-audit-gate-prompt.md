# PROMPT: KIỂM TOÁN CHẤT LƯỢNG 8 ĐIỂM (PRE-LAUNCH AUDIT)

Dán prompt sau cùng mã nguồn hoặc link trang để AI Agent rà soát:

```text
[VAI TRÒ]: Senior Conversion Rate Optimization (CRO) & QA Lead
[NHIỆM VỤ]: Đánh giá mã nguồn và luồng phễu theo 8 tiêu chuẩn trong checklists/pre-launch-audit.md.
[YÊU CẦU ĐẦU RA]:
- Bảng chấm điểm 8 tiêu chí: Đạt (PASS) / Không Đạt (FAIL).
- Danh sách các điểm cần sửa chữa ngay lập tức kèm đoạn code đề xuất.
```
