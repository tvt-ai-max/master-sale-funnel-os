# 🚀 HƯỚNG DẪN BẮT ĐẦU NHANH 1-CLICK (VIP ONBOARDING GUIDE)
### *Hệ Thống Enterprise Master Funnel OS v3.0 & Hermes AI Agent Core*
**Tác giả:** Nguyễn Thanh Tùng ([toilatung.com](https://toilatung.com)) & TVT Agency  
**Hỗ trợ kỹ thuật trực tiếp:** Zalo `0972 613 555` | Email: `contact@toilatung.com`

---

## 🎁 CHÚC MỪNG BẠN ĐÃ SỞ HỮU BỘ KHUNG ENTERPRISE MASTER FUNNEL OS v3.0!

Bạn đang nắm trong tay toàn bộ **5 Vũ Khí Bí Mật** đã được tối ưu hóa theo tâm lý học hành vi và kiểm chứng thực tế tại TVT Agency. Tài liệu này giúp bạn khởi chạy hệ thống ngay lập tức với phương châm **"1-Click Plug & Play"**.

---

## ⚡ 1. KHỞI CHẠY 1-CLICK THEO NHU CẦU CỦA BẠN:

Tuỳ theo trình độ kỹ thuật và mục đích sử dụng, bạn hãy chọn 1 trong 3 cách sau:

### 🟢 CÁCH 1: DÀNH CHO FOUNDER & MARKETER (KHÔNG CẦN BIẾT CODE)
> **Mục tiêu:** Mở và chỉnh sửa trang Sale Page bán hàng để chạy quảng cáo hoặc gửi khách ngay lập tức.

1. Vào thư mục `sale-page/`.
2. **Nhấp đúp chuột** vào tệp `index.html` → Trang bán hàng sẽ mở ngay trên trình duyệt Chrome/Safari/Edge của bạn.
3. **Thay đổi thông tin nhận tiền VietQR:**
   - Mở file `sale-page/index.html` bằng Notepad hoặc bất kỳ trình soạn thảo nào.
   - Tìm số điện thoại `0972 613 555` và STK `0912210457` (MB Bank) → Thay bằng STK và SĐT của bạn.
   - Lưu lại và tải toàn bộ thư mục `sale-page/` lên bất kỳ Hosting/VPS hoặc Vercel/Netlify/GitHub Pages hoàn toàn miễn phí.

---

### 🟡 CÁCH 2: DÀNH CHO OPERATOR (CHẠY TRỢ LÝ HERMES AI AGENT 1-CLICK)
> **Mục tiêu:** Kích hoạt trợ lý AI thông minh Hermes Agent tự động đọc thông tin sản phẩm và xuất bản phễu.

* **Trên MacOS / Linux:**
  1. Mở Terminal tại thư mục `SKILL-SALE-FUNNEL`.
  2. Gõ lệnh:
     ```bash
     chmod +x quickstart.sh && ./quickstart.sh
     ```
  3. Chọn phím `[2]` để hệ thống tự động cài đặt môi trường và khởi chạy Hermes Agent.

* **Trên Windows:**
  1. **Nhấp đúp chuột** vào tệp `quickstart.bat`.
  2. Chọn phím `[2]` → Màn hình tương tác Hermes AI CLI sẽ xuất hiện với đầy đủ màu sắc và menu lệnh.

---

### 🔴 CÁCH 3: DÀNH CHO AGENCY & TECH LEAD (KHỞI CHẠY CỤM DOCKER + N8N)
> **Mục tiêu:** Vận hành hạ tầng tự động hóa khép kín: Tự động gửi Email, bắn Meta CAPI, webhook SePay và Telegram Bot.

1. Chạy lệnh Docker Compose:
   ```bash
   cd infrastructure/docker
   docker compose up -d
   ```
2. Truy cập n8n Workflow Engine tại: `http://localhost:5678`
3. Import 5 workflow mẫu có sẵn từ thư mục `infrastructure/n8n-workflows/`:
   - `01_vietqr_payment_webhook.json` (Xử lý thanh toán VietQR)
   - `02_instant_lead_capture_routing.json` (Phân luồng Lead)
   - `03_email_drip_scheduler.json` (Chuỗi Email nuôi dưỡng)
   - `04_meta_capi_purchase_dispatcher.json` (Server-side CAPI)
   - `05_telegram_chatbot_support_flow.json` (Telegram Bot thông báo)

---

## 📂 2. BẢNG TRA CỨU NHANH 6 PRESETS NGÀNH NGHỀ (`presets/`):

Khi làm dự án cho khách hàng, bạn chỉ cần mở file trong thư mục `presets/` để lấy toàn bộ kịch bản, màu sắc và lời hứa chuyển đổi:

| Mã Preset | Ngành Nghề | File Cấu Hình | Điểm Nhấn Chuyển Đổi |
| :--- | :--- | :--- | :--- |
| **IND-01** | B2B SaaS & Công Nghệ | `presets/01-b2b-saas/` | Live Demo, Free Trial, Bảng tính ROI |
| **IND-02** | Thẩm Mỹ, Spa & Clinic | `presets/02-beauty-spa/` | Voucher trải nghiệm 99k, Before/After |
| **IND-03** | Khóa Học & Coaching | `presets/03-education-coaching/` | Workshop 3 ngày, Lộ trình, Bộ quà tặng lớn |
| **IND-04** | Bất Động Sản | `presets/04-real-estate/` | Bảng giá đợt 1, VIP Site Tour đưa đón |
| **IND-05** | E-commerce D2C | `presets/05-ecommerce-d2c/` | Flash Sale, Bundle combo, Mua nhanh 1-Click |
| **IND-06** | Dịch Vụ B2B & Agency | `presets/06-b2b-agency/` | Báo cáo Audit 0đ, Portfolio năng lực |

---

## 🛠️ 3. TỰ CHỈNH SỬA CHO DỰ ÁN MỚI TRONG 1 NỐT NHẠC:

1. Mở file `configs/client-project-config.template.yaml`.
2. Điền 5 thông tin cơ bản:
   - `brand_name`: Tên thương hiệu.
   - `core_product_name`: Tên sản phẩm chính.
   - `offer_price`: Giá bán ưu đãi.
   - `primary_buyer`: Chân dung khách hàng mục tiêu.
   - `top_3_pains`: 3 nỗi đau lớn nhất của khách.
3. Nạp file này cho **Hermes AI Agent** hoặc **Claude Code / ChatGPT** → Hệ thống sẽ tự động xuất bản toàn bộ nội dung phễu mới chuẩn 100%!

---

## 📞 4. CHÍNH SÁCH BẢO HÀNH & HỖ TRỢ KỸ THUẬT:

- **Bản quyền thương mại vĩnh viễn:** Bạn có toàn quyền sử dụng để xây dựng phễu cho chính mình và cho vô số khách hàng của Agency.
- **Hỗ trợ kỹ thuật 1-1:** Nếu bạn gặp bất kỳ trở ngại nào trong quá trình cài đặt, hãy liên hệ ngay:
  - **Zalo Chuyên Gia:** `0972 613 555` (Nguyễn Thanh Tùng)
  - **Email:** `contact@toilatung.com`
  - **Hệ sinh thái tri thức:** [toilatung.com/skills](https://toilatung.com/skills)

---
*Chúc bạn bùng nổ doanh số và xây dựng được những cỗ máy tự động hóa chuyển đổi cao vượt bậc!*
