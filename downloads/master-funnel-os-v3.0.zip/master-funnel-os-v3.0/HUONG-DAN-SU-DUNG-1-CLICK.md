# 🚀 HƯỚNG DẪN BẮT ĐẦU NHANH 1-CLICK (VIP ONBOARDING GUIDE)
### *Hệ Thống Enterprise Master Funnel OS v3.0 & Hermes AI Agent Core*
**Tác giả:** Nguyễn Thanh Tùng ([toilatung.com](https://toilatung.com)) & TVT Agency  
**Hỗ trợ kỹ thuật trực tiếp:** Zalo `0972 613 555` | Email: `contact@toilatung.com`

---

## 🎁 CHÚC MỪNG BẠN ĐÃ SỞ HỮU BỘ KHUNG MASTER FUNNEL OS v3.0!

Bạn đang nắm trong tay toàn bộ **5 Vũ Khí Bí Mật** đã được đóng gói sẵn để triển khai phễu bán hàng tự động hóa và thu tiền 24/7.

---

## ⚡ 1. KHỞI CHẠY 1-CLICK THEO NHU CẦU CỦA BẠN:

### 🟢 CÁCH 1: DÀNH CHO FOUNDER & MARKETER (TÙY BIẾN LANDING PAGE NHANH)
> **Mục tiêu:** Mở và tùy chỉnh Landing Page mẫu theo sản phẩm và thương hiệu của bạn trong 3 phút.

1. Vào thư mục `templates/`.
2. **Nhấp đúp chuột** vào tệp `landing-page-template.html` → Xem ngay mẫu Landing Page chuyển đổi cao trên trình duyệt.
3. **Thay đổi thông tin nhận tiền VietQR:**
   - Mở file `templates/landing-page-template.html` bằng Notepad/VS Code.
   - Thay STK ngân hàng, Tên sản phẩm và Giá bán của bạn.
   - Xuất bản lên Vercel, Netlify hoặc Hosting của bạn hoàn toàn miễn phí.

---

### 🟡 CÁCH 2: DÀNH CHO OPERATOR (CHẠY TRỢ LÝ HERMES AI AGENT 1-CLICK)
> **Mục tiêu:** Kích hoạt trợ lý AI thông minh Hermes Agent tự động đọc thông tin sản phẩm và xuất bản phễu.

* **Trên MacOS / Linux:**
  1. Mở Terminal tại thư mục giải nén.
  2. Gõ lệnh:
     ```bash
     bash quickstart.sh
     ```
  3. Chọn phím `[2]` để khởi chạy Hermes Agent tương tác tự động.

* **Trên Windows:**
  1. **Nhấp đúp chuột** vào tệp `quickstart.bat`.
  2. Chọn phím `[2]` → Màn hình tương tác Hermes AI CLI sẽ xuất hiện ngay.

---

### 🔴 CÁCH 3: DÀNH CHO AGENCY & TECH LEAD (KHỞI CHẠY CỤM DOCKER + N8N)
> **Mục tiêu:** Vận hành hạ tầng tự động hóa khép kín: Tự động gửi Email Resend, Webhook SePay VietQR, và Telegram Bot.

1. Chạy lệnh Docker Compose:
   ```bash
   cd infrastructure/docker
   docker compose up -d
   ```
2. Truy cập n8n Workflow Engine tại: `http://localhost:5678`
3. Import 5 workflow mẫu có sẵn từ thư mục `infrastructure/n8n-workflows/`.

---

## 🏢 2. BẢNG 6 PRESETS NGÀNH NGHỀ MAY ĐO SẴN (`presets/`):

| Mã Preset | Ngành Nghề | File Cấu Hình | Điểm Nhấn Chuyển Đổi |
| :--- | :--- | :--- | :--- |
| **IND-01** | B2B SaaS & Công Nghệ | `presets/01-b2b-saas-tech/` | Live Demo, Free Trial, Bảng tính ROI |
| **IND-02** | Thẩm Mỹ, Spa & Clinic | `presets/02-clinic-spa-beauty/` | Voucher trải nghiệm 99k, Before/After |
| **IND-03** | Khóa Học & Coaching | `presets/03-education-coaching/` | Workshop 3 ngày, Lộ trình, Quà tặng lớn |
| **IND-04** | Bất Động Sản | `presets/04-real-estate-invest/` | Bảng giá đợt 1, VIP Site Tour đưa đón |
| **IND-05** | E-commerce D2C | `presets/05-ecommerce-d2c/` | Flash Sale, Bundle combo, Mua nhanh 1-Click |
| **IND-06** | Dịch Vụ B2B & Agency | `presets/06-agency-services/` | Báo cáo Audit 0đ, Portfolio năng lực |

---

## 🛡️ 3. KIỂM TOÁN PHỄU 30 ĐIỂM CHUẨN TRƯỚC KHI CHẠY ADS (`audit-gate/`):

Trước khi chi tiền quảng cáo, bạn hãy chạy script kiểm toán tự động:
```bash
python3 audit-gate/30-point-audit-validator.py templates/landing-page-template.html
```
Hệ thống sẽ chấm điểm chi tiết từ 0 - 10 điểm để đảm bảo tỷ lệ chuyển đổi cao nhất.

---

## 📞 4. HỖ TRỢ KỸ THUẬT 1-1 TRỰC TIẾP TỪ TÁC GIẢ:

- **Zalo Hỗ Trợ Kỹ Thuật:** `0972 613 555` (Nguyễn Thanh Tùng)
- **Email:** `contact@toilatung.com`
- **Cộng đồng & Hệ tri thức:** [toilatung.com](https://toilatung.com)
