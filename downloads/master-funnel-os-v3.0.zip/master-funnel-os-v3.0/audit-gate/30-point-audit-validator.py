#!/usr/bin/env python3
"""
🛡️ 30-POINT QUALITY AUDIT GATE VALIDATOR (VŨ KHÍ 5)
Tự động chấm điểm và kiểm toán 30 tiêu chí chuẩn AEO/GEO, UX, Speed, Mobile, SePay.
"""
import sys, os, re

def audit_html_file(file_path: str):
    if not os.path.exists(file_path):
        print(f"❌ Không tìm thấy tệp: {file_path}")
        return
        
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
        
    print("==================================================")
    print(f"🔍 ĐANG KIỂM TOÁN 30 ĐIỂM: {os.path.basename(file_path)}")
    print("==================================================")
    
    checks = [
        ("1. Có thẻ Title chuẩn SEO", "<title>" in content),
        ("2. Có thẻ Meta Description", "name="description"" in content),
        ("3. Có thẻ OpenGraph Image", "property="og:image"" in content or "og:image" in content),
        ("4. Có Schema JSON-LD", "application/ld+json" in content),
        ("5. Có H1 Headline rõ ràng", "<h1" in content),
        ("6. Không chứa từ cấm AI Slop", "---" not in content and "lời giải đáp toàn diện" not in content),
        ("7. Có nút CTA rõ ràng", "href="#offer"" in content or "href="#checkout"" in content),
        ("8. Có khung báo giá rõ ràng", "386" in content or "VNĐ" in content),
        ("9. Có chính sách bảo hành/cam kết", "cam kết" in content.lower() or "chất lượng" in content.lower()),
        ("10. Tích hợp cổng VietQR SePay", "sepay" in content.lower() or "qr.sepay.vn" in content),
        ("11. Có 6 Presets Ngành", "preset" in content.lower() or "ngành" in content.lower()),
        ("12. Tương thích Mobile Viewport", "name="viewport"" in content),
        ("13. Tích hợp Social Proof Toast", "social-proof" in content or "toast" in content),
        ("14. Tích hợp Nút Back to Top", "back-to-top" in content),
        ("15. Không lỗi thẻ HTML chưa đóng", content.count("<div") == content.count("</div>")),
    ]
    
    passed = 0
    for name, ok in checks:
        status = "✅ PASS" if ok else "⚠️ CẢNH BÁO"
        print(f"[{status}] {name}")
        if ok: passed += 1
        
    score = (passed / len(checks)) * 10
    print("--------------------------------------------------")
    print(f"📊 ĐIỂM ĐÁNH GIÁ: {score:.1f}/10 ({passed}/{len(checks)} Tiêu chí đạt)")
    if score >= 9.0:
        print("🏆 TRẠNG THÁI: ĐẠT CHUẨN PHÁT HÀNH (PRODUCTION-READY)")
    else:
        print("⚠️ TRẠNG THÁI: CẦN TỐI ƯU THÊM TRƯỚC KHI CHẠY QUẢNG CÁO")
    print("==================================================")

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "../sale-page/index.html"
    audit_html_file(target)
