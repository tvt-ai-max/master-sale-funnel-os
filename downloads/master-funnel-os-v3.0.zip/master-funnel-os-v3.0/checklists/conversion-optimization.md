# CHECKLIST TỐI ƯU HÓA TỶ LỆ CHUYỂN ĐỔI (CRO)

- [ ] Nút CTA chính nổi bật và luôn xuất hiện ít nhất 3 lần trên trang (Đầu trang, Giữa trang, Cuối trang).
- [ ] Bằng chứng xã hội (Testimonial/Feedback) đặt ngay sau khối giới thiệu giải pháp để củng cố niềm tin.
- [ ] Bảng giá có sự phân cấp rõ ràng giữa mức giá gốc gạch ngang và giá ưu đãi thực tế.
- [ ] Chính sách hoàn tiền hoặc cam kết bảo hành được làm nổi bật với biểu tượng rõ ràng.
- [ ] Thêm đồng hồ đếm ngược hoặc số lượng giới hạn để thúc đẩy hành động ngay.
