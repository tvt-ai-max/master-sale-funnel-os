# CHECKLIST 8 ĐIỂM KIỂM TOÁN TRƯỚC KHI LAUNCH

- [ ] **1. Tương Thích Mobile:** Đã kiểm tra trên màn hình 375px (iPhone SE) và 390px (iPhone 14/15), không bị lỗi tràn khung hay chữ quá to.
- [ ] **2. Tốc Độ Tải Trang:** Hình ảnh đã chuyển sang định dạng `.webp`, thời gian load trang dưới 2 giây.
- [ ] **3. Form Xác Thực:** Form chặn số điện thoại rác (phải đủ 10 số) và email sai định dạng.
- [ ] **4. VietQR Tự Động:** Mã QR quét thử ra đúng số tài khoản, số tiền và nội dung chuyển khoản tự động.
- [ ] **5. Webhook Hoạt Động:** Biến động số dư kích hoạt webhook và cập nhật dữ liệu CRM thành công.
- [ ] **6. Email Xác Thực:** Tên miền gửi email có bản ghi SPF, DKIM, DMARC hợp lệ; email vào thẳng Inbox.
- [ ] **7. Tracking Đồng Bộ:** Cài đặt Meta Pixel kết hợp CAPI, kiểm tra mã `event_id` trùng khớp giữa 2 tầng.
- [ ] **8. Chất Lượng Copy & UI:** Loại bỏ toàn bộ lỗi chính tả, liên kết hỏng và từ ngữ sáo rỗng AI Slop.
