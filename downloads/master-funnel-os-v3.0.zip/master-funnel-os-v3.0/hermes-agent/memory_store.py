import sqlite3
import json
import os
from datetime import datetime

class HermesMemoryStore:
    def __init__(self, db_path="hermes_memory.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS project_contexts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                brand_name TEXT UNIQUE,
                industry_code TEXT,
                raw_config TEXT,
                created_at DATETIME,
                updated_at DATETIME
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS learned_insights (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT,
                insight TEXT,
                created_at DATETIME
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS chat_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT,
                role TEXT,
                content TEXT,
                timestamp DATETIME
            )
        """)
        conn.commit()
        conn.close()

    def save_project_context(self, brand_name, industry_code, config_dict):
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        now = datetime.now().isoformat()
        cur.execute("""
            INSERT INTO project_contexts (brand_name, industry_code, raw_config, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(brand_name) DO UPDATE SET
                industry_code=excluded.industry_code,
                raw_config=excluded.raw_config,
                updated_at=excluded.updated_at
        """, (brand_name, industry_code, json.dumps(config_dict, ensure_ascii=False), now, now))
        conn.commit()
        conn.close()

    def get_latest_project(self):
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("SELECT brand_name, industry_code, raw_config FROM project_contexts ORDER BY updated_at DESC LIMIT 1")
        row = cur.fetchone()
        conn.close()
        if row:
            return {"brand_name": row[0], "industry_code": row[1], "config": json.loads(row[2])}
        return None

    def log_message(self, session_id, role, content):
        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()
        cur.execute("INSERT INTO chat_history (session_id, role, content, timestamp) VALUES (?, ?, ?, ?)",
                    (session_id, role, content, datetime.now().isoformat()))
        conn.commit()
        conn.close()
