#!/bin/bash
set -e

echo "=================================================="
echo "🚀 ĐANG KHỞI TẠO BỘ CÀI ĐẶT HERMES AI AGENT..."
echo "=================================================="

# Kiểm tra Python 3
if ! command -v python3 &> /dev/null; then
    echo "❌ Lỗi: Chưa tìm thấy Python 3 trên hệ thống. Vui lòng cài đặt Python 3.10+ trước."
    exit 1
fi

echo "✅ Đã phát hiện Python trên hệ thống."

# Tạo môi trường ảo venv
if [ ! -d "venv" ]; then
    echo "📦 Đang tạo môi trường ảo Python (venv)..."
    python3 -m venv venv
fi

# Kích hoạt venv
source venv/bin/activate

# Nâng cấp pip và cài đặt thư viện
echo "📥 Đang cài đặt các thư viện cần thiết..."
pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet

# Khởi tạo file cấu hình nếu chưa có
if [ ! -f "config.yaml" ]; then
    echo "⚙️ Đang sao chép file cấu hình config.yaml từ template..."
    cp config.template.yaml config.yaml
    echo "⚠️ HÃY MỞ FILE 'config.yaml' VÀ ĐIỀN API KEY CỦA BẠN TRƯỚC KHI CHẠY."
fi

echo "=================================================="
echo "🎉 CÀI ĐẶT HERMES AI AGENT HOÀN TẤT!"
echo "👉 Để khởi chạy Agent, hãy gõ lệnh:"
echo "   source venv/bin/activate && python run_agent.py"
echo "=================================================="
