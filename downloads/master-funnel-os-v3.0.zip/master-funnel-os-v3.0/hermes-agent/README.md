# 🤖 BỘ CÀI ĐẶT HERMES AI AGENT CORE
### *Autonomous Execution Engine For Sale Funnel & Marketing Automation*

**Hermes AI Agent** là động cơ AI Agent độc lập, mã nguồn mở, cho phép bạn vận hành các tác vụ phân tích thị trường, viết copy chuyển đổi cao, thiết kế giao diện Tailwind và kết nối marketing automation trực tiếp trên máy trạm (Local Workstation) hoặc máy chủ VPS của bạn.

---

## 🌟 TÍNH NĂNG NỔI BẬT CỦA HERMES AGENT
1. **Dynamic Skills Loading:** Tự động nhận diện và nạp 10 Sub-Skills cùng 6 Industry Presets từ thư mục `../skills/` và `../presets/`.
2. **Persistent Long-Term Memory:** Lưu trữ thông tin khách hàng, Brand DNA và bài học kinh nghiệm vào cơ sở dữ liệu cục bộ (`hermes_memory.db`).
3. **Multi-Model Provider:** Hỗ trợ kết nối linh hoạt với **OpenAI (GPT-4o)**, **Anthropic (Claude 3.5 Sonnet)**, **Google Gemini (2.5/Flash)**, **OpenRouter** hoặc mô hình Local Offline (**Ollama**).
4. **Anti-AI Slop Guard:** Tích hợp sẵn bộ lọc chất lượng rà soát và từ chối các đoạn mã/copy sáo rỗng trước khi xuất ra cho người dùng.

---

## ⚡ HƯỚNG DẪN CÀI ĐẶT NHANH (3 BƯỚC)

### Cách 1: Cài đặt tự động bằng Script (Khuyên dùng)

#### Trên MacOS / Linux / VPS:
```bash
cd hermes-agent
chmod +x install.sh
./install.sh
```

#### Trên Windows:
Chạy file `install.bat` bằng cách nhấp đúp hoặc chạy trong PowerShell:
```powershell
cd hermes-agent
.\install.bat
```

---

### Cách 2: Cài đặt thủ công bằng Python Virtualenv

```bash
# 1. Tạo môi trường ảo
python3 -m venv venv

# 2. Kích hoạt môi trường ảo
# Trên Mac/Linux:
source venv/bin/activate
# Trên Windows:
.\venv\Scripts\activate

# 3. Cài đặt các thư viện cần thiết
pip install -r requirements.txt

# 4. Sao chép và điền file cấu hình
cp config.template.yaml config.yaml
```

---

### Cách 3: Khởi chạy bằng Docker Compose (Container hóa)

```bash
docker-compose up -d --build
docker exec -it hermes_agent_runner python run_agent.py
```

---

## ⚙️ CẤU HÌNH API KEYS TRONG `config.yaml`

Mở file `config.yaml` và điền ít nhất 1 khóa API:

```yaml
# Nhà cung cấp mô hình AI mặc định: [gemini, openai, claude, openrouter, ollama]
default_provider: "gemini" # hoặc "openai", "claude"

api_keys:
  gemini_api_key: "your_gemini_api_key_here"
  openai_api_key: "your_openai_api_key_here"
  anthropic_api_key: "your_anthropic_api_key_here"
  openrouter_api_key: "your_openrouter_api_key_here"

model_names:
  gemini: "gemini-2.5-flash"
  openai: "gpt-4o"
  claude: "claude-3-5-sonnet-20241022"
  ollama: "qwen2.5-coder:latest"
```

---

## 🚀 HƯỚNG DẪN SỬ DỤNG HERMES AGENT

Chạy lệnh tương tác với Agent:
```bash
python run_agent.py
```

### Các lệnh điều khiển nhanh trong phiên chat:
- `/project [tên_file]`: Nạp tệp cấu hình dự án khách hàng (ví dụ: `/project ../configs/client-project-config.template.yaml`).
- `/skills`: Liệt kê danh sách các bộ skill và preset ngành nghề đang sẵn sàng.
- `/audit`: Yêu cầu Hermes kích hoạt chế độ `@PersonalMasterAuditor` kiểm toán 30 điểm.
- `/memory`: Xem lại các thông tin Brand DNA đã được lưu trong bộ nhớ.
- `/clear`: Xóa ngữ cảnh phiên chat hiện tại.
- `/exit`: Thoát chương trình.
