@echo off
echo ==================================================
echo ĐANG KHỞI TẠO BỘ CÀI ĐẶT HERMES AI AGENT (WINDOWS)...
echo ==================================================

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [LỖI] Chưa tìm thấy Python. Vui lòng cài đặt Python 3.10+ và tích chọn 'Add Python to PATH'.
    pause
    exit /b 1
)

if not exist venv (
    echo [1/3] Đang tạo môi trường ảo Python venv...
    python -m venv venv
)

echo [2/3] Đang kích hoạt venv và cài đặt thư viện...
call venv\Scripts\activate.bat
pip install --upgrade pip
pip install -r requirements.txt

if not exist config.yaml (
    echo [3/3] Đang tạo file config.yaml...
    copy config.template.yaml config.yaml
    echo [LƯU Ý] Hãy mở file config.yaml và điền API Key trước khi chạy.
)

echo ==================================================
echo CÀI ĐẶT HOÀN TẤT!
echo Chạy lệnh sau để khởi động Hermes:
echo venv\Scripts\activate ^&^& python run_agent.py
echo ==================================================
pause
