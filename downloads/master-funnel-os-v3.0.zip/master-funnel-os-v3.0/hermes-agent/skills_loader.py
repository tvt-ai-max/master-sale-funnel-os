import os
import yaml

class HermesSkillsLoader:
    def __init__(self, skills_dir="../skills", presets_dir="../presets"):
        self.skills_dir = skills_dir
        self.presets_dir = presets_dir

    def load_all_skills(self):
        skills_summary = {}
        if not os.path.exists(self.skills_dir):
            return skills_summary

        for root, _, files in os.walk(self.skills_dir):
            for file in files:
                if file.endswith(".md"):
                    path = os.path.join(root, file)
                    skill_name = os.path.basename(os.path.dirname(path)) if os.path.dirname(path) != self.skills_dir else "master"
                    try:
                        with open(path, "r", encoding="utf-8") as f:
                            content = f.read()
                            skills_summary[skill_name] = content
                    except Exception as e:
                        pass
        return skills_summary

    def load_industry_preset(self, industry_code):
        industry_map = {
            "IND-01": "01-b2b-saas-tech",
            "IND-02": "02-clinic-spa-beauty",
            "IND-03": "03-education-coaching",
            "IND-04": "04-real-estate-invest",
            "IND-05": "05-ecommerce-d2c",
            "IND-06": "06-agency-services"
        }
        folder_name = industry_map.get(industry_code)
        if not folder_name:
            return ""

        preset_file = os.path.join(self.presets_dir, folder_name, "PRESET.md")
        if os.path.exists(preset_file):
            with open(preset_file, "r", encoding="utf-8") as f:
                return f.read()
        return ""
