import os
import sys
import yaml
import json
import requests
from datetime import datetime
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.prompt import Prompt

from memory_store import HermesMemoryStore
from skills_loader import HermesSkillsLoader

console = Console()

class HermesAgentRunner:
    def __init__(self, config_path="config.yaml"):
        self.config_path = config_path
        self.config = self._load_config()
        self.memory = HermesMemoryStore(self.config.get("paths", {}).get("memory_db", "hermes_memory.db"))
        self.loader = HermesSkillsLoader(
            self.config.get("paths", {}).get("skills_dir", "../skills"),
            self.config.get("paths", {}).get("presets_dir", "../presets")
        )
        self.session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.current_project = self.memory.get_latest_project()
        self.system_prompt = self._build_system_prompt()
        self.conversation = [{"role": "system", "content": self.system_prompt}]

    def _load_config(self):
        if not os.path.exists(self.config_path):
            console.print(f"[bold red]❌ Chưa tìm thấy file '{self.config_path}'. Vui lòng copy từ config.template.yaml.[/bold red]")
            sys.exit(1)
        with open(self.config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)

    def _build_system_prompt(self):
        base_prompt = ""
        if os.path.exists("system_prompt.md"):
            with open("system_prompt.md", "r", encoding="utf-8") as f:
                base_prompt = f.read()
        
        project_context = ""
        if self.current_project:
            p = self.current_project
            preset = self.loader.load_industry_preset(p.get("industry_code", ""))
            project_context = f"""
\n---
### 📌 THÔNG TIN DỰ ÁN ĐANG THỰC HIỆN:
- Thương hiệu: {p.get('brand_name')}
- Ngành nghề: {p.get('industry_code')}
- Cấu hình chi tiết: {json.dumps(p.get('config', {}), ensure_ascii=False)}

### 🎨 PRESET NGÀNH ĐƯỢC KÍCH HOẠT:
{preset}
"""
        return f"{base_prompt}\n{project_context}"

    def load_project_file(self, file_path):
        if not os.path.exists(file_path):
            console.print(f"[bold red]❌ Không tìm thấy file: {file_path}[/bold red]")
            return
        with open(file_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        brand = data.get("client_info", {}).get("brand_name", "Unknown Brand")
        ind_code = data.get("client_info", {}).get("industry_code", "IND-01")
        self.memory.save_project_context(brand, ind_code, data)
        self.current_project = {"brand_name": brand, "industry_code": ind_code, "config": data}
        self.system_prompt = self._build_system_prompt()
        self.conversation[0] = {"role": "system", "content": self.system_prompt}
        console.print(f"[bold green]✅ Đã nạp thành công dự án: '{brand}' (Ngành: {ind_code})[/bold green]")

    def call_llm(self, user_msg):
        provider = self.config.get("runtime", {}).get("default_provider", "gemini")
        api_keys = self.config.get("api_keys", {})
        models = self.config.get("models", {})
        
        self.conversation.append({"role": "user", "content": user_msg})
        self.memory.log_message(self.session_id, "user", user_msg)

        console.print("[dim]🤖 Hermes đang xử lý và đối soát tiêu chuẩn chuyển đổi...[/dim]")

        # 1. Google Gemini API Connector
        if provider == "gemini":
            key = api_keys.get("gemini_api_key")
            if not key:
                return "❌ Lỗi: Chưa điền gemini_api_key trong config.yaml."
            model = models.get("gemini", "gemini-2.5-flash")
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
            contents = []
            for m in self.conversation:
                role = "user" if m["role"] in ["user", "system"] else "model"
                contents.append({"role": role, "parts": [{"text": m["content"]}]})
            resp = requests.post(url, json={"contents": contents}, timeout=60)
            if resp.status_code == 200:
                res_text = resp.json()["candidates"][0]["content"]["parts"][0]["text"]
                self.conversation.append({"role": "assistant", "content": res_text})
                self.memory.log_message(self.session_id, "assistant", res_text)
                return res_text
            else:
                return f"❌ Lỗi Gemini API ({resp.status_code}): {resp.text}"

        # 2. OpenAI / OpenRouter / Ollama Connector
        elif provider in ["openai", "openrouter", "ollama"]:
            base_url = "https://api.openai.com/v1" if provider == "openai" else (
                "https://openrouter.ai/api/v1" if provider == "openrouter" else self.config.get("api_keys", {}).get("ollama_base_url", "http://localhost:11434") + "/v1"
            )
            key = api_keys.get(f"{provider}_api_key", "ollama")
            model = models.get(provider, "gpt-4o")
            headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
            resp = requests.post(f"{base_url}/chat/completions", headers=headers, json={
                "model": model,
                "messages": self.conversation,
                "temperature": self.config.get("runtime", {}).get("temperature", 0.3)
            }, timeout=60)
            if resp.status_code == 200:
                res_text = resp.json()["choices"][0]["message"]["content"]
                self.conversation.append({"role": "assistant", "content": res_text})
                self.memory.log_message(self.session_id, "assistant", res_text)
                return res_text
            else:
                return f"❌ Lỗi {provider.upper()} API ({resp.status_code}): {resp.text}"
        
        return f"❌ Nhà cung cấp '{provider}' chưa được hỗ trợ."

    def start_cli(self):
        console.clear()
        console.print(Panel.fit(
            "[bold cyan]🤖 HERMES AI AGENT OPERATING CONSOLE v2.0[/bold cyan]\n"
            "[dim]Động cơ tự trị xây dựng Sale Funnel & Marketing Automation đa ngành[/dim]\n\n"
            "• Gõ [yellow]/project [đường_dẫn][/yellow] để nạp cấu hình khách hàng\n"
            "• Gõ [yellow]/skills[/yellow] để xem danh mục 10 sub-skills có sẵn\n"
            "• Gõ [yellow]/audit[/yellow] để kích hoạt Master Auditor 30 điểm\n"
            "• Gõ [yellow]/exit[/yellow] để thoát",
            title="Hermes Autonomous Engine",
            border_style="cyan"
        ))
        if self.current_project:
            console.print(f"[green]📌 Dự án đang mở:[/green] [bold]{self.current_project['brand_name']}[/bold] (Mã ngành: {self.current_project['industry_code']})\n")

        while True:
            try:
                user_input = Prompt.ask("[bold green]Operator[/bold green]").strip()
                if not user_input:
                    continue
                if user_input.lower() in ["/exit", "exit", "quit"]:
                    console.print("[yellow]Tạm biệt! Hermes Agent đang dừng tiến trình an toàn.[/yellow]")
                    break
                elif user_input.startswith("/project "):
                    path = user_input.replace("/project ", "").strip()
                    self.load_project_file(path)
                    continue
                elif user_input == "/skills":
                    skills = self.loader.load_all_skills()
                    console.print(f"[bold cyan]📚 Đã nạp {len(skills)} Sub-Skills chuyên sâu sẵn sàng thực thi.[/bold cyan]")
                    continue
                elif user_input == "/audit":
                    user_input = "Hãy đóng vai @PersonalMasterAuditor và thực thi toàn bộ 30 tiêu chí kiểm toán cho dự án này theo file audits/360-master-audit-framework.md."
                
                response = self.call_llm(user_input)
                console.print("\n[bold cyan]Hermes AI Agent[/bold cyan]:")
                console.print(Markdown(response))
                console.print("\n" + "-"*60 + "\n")
            except KeyboardInterrupt:
                break
            except Exception as e:
                console.print(f"[bold red]❌ Đã xảy ra lỗi: {e}[/bold red]")

if __name__ == "__main__":
    runner = HermesAgentRunner()
    runner.start_cli()
