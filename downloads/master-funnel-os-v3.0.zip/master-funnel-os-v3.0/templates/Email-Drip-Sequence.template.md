# EMAIL DRIP SEQUENCE (CHUỖI 3 EMAIL CHĂM SÓC)

## EMAIL 1: CHÚC MỪNG & KÍCH HOẠT TÀI NGUYÊN (GỬI NGAY - PHÚT 0)
- **Tiêu đề:** [Xác nhận] Quyền truy cập gói tài nguyên [Tên Sản Phẩm] của bạn
- **Nội dung:**
  * Chào [Tên Khách Hàng],
  * Chúc mừng bạn đã có một quyết định tuyệt vời. Toàn bộ tài nguyên của bạn đã sẵn sàng.
  * Đường dẫn truy cập: [Link Kích Hoạt]
  * Thông tin tài khoản: [Username / Email]
  * Bước đầu tiên bạn cần làm ngay lúc này: [Hành động nhỏ 5 phút].

## EMAIL 2: BƯỚC ĐI ĐẦU TIÊN ĐỂ CÓ KẾT QUẢ NHANH (SAU 24 GIỜ)
- **Tiêu đề:** Bước quan trọng nhất để đạt kết quả trong 24 giờ tới
- **Nội dung:**
  * Chia sẻ 1 mẹo thực chiến giúp họ có kết quả ngay lập tức (Quick Win).
  * Cảnh báo 2 lỗi phổ biến mà người mới hay mắc phải và cách phòng tránh.
  * Nhắc nhở liên hệ hỗ trợ nếu gặp khó khăn kỹ thuật.

## EMAIL 3: CÂU CHUYỆN THỰC CHIẾN & CƠ HỘI NÂNG CẤP (SAU 72 GIỜ)
- **Tiêu đề:** Cách [Tên Khách Hàng Mẫu] đã tối ưu x3 kết quả như thế nào?
- **Nội dung:**
  * Phân tích case study thực tế áp dụng thành công.
  * Giới thiệu gói giải pháp cao cấp hơn (Coaching / Dịch vụ trọn gói) cho những ai muốn đi nhanh hơn.
