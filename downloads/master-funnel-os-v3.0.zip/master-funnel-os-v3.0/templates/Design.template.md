# DESIGN SPECIFICATION (SSOT)
- Primary Color: #0F172A (Deep Slate)
- Accent / CTA Color: #2563EB (Vibrant Royal Blue)
- Background: #FFFFFF (Clean White) / #F8FAFC (Light Gray Card)
- Text Color: #1E293B (Slate 800) / Secondary: #64748B (Slate 500)
- Font Family: Inter, sans-serif
- Typography Scale:
  * H1: 36px (Mobile) / 48px (Desktop) - font-bold
  * H2: 28px (Mobile) / 36px (Desktop) - font-semibold
  * H3: 20px / 24px - font-medium
  * Body: 16px - font-normal, line-height 1.6
- Spacing Scale: Section padding py-16 md:py-24, Container max-w-6xl mx-auto px-4
- Negative Directives:
  * CẤM dùng gradient quá 2 màu.
  * CẤM bo góc card quá 16px.
  * CẤM lạm dụng emoji quá đà.
