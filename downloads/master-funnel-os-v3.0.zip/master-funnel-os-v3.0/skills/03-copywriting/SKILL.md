---
name: funnel-direct-copywriting
description: Biên soạn nội dung 10 Sections cho Sale Page theo công thức phản hồi trực tiếp (Direct Response).
---

# SKILL: DIRECT RESPONSE COPYWRITING (10 SECTIONS)

## 📋 Cấu Trúc 10 Khối Chuyển Đổi Bắt Buộc
1. **Hero Banner:** Hook mạnh mẽ + Lợi ích đo lường được + CTA.
2. **Problem Identification:** Mô tả đúng thực trạng khách hàng đang bế tắc.
3. **Agitation:** Khoét sâu tổn thất nếu không hành động ngay.
4. **The Mechanism / Solution:** Cơ chế giải pháp mới mẻ, thuyết phục.
5. **Features & Tangible Benefits:** Tính năng đi liền với giá trị thực tế.
6. **Social Proof / Case Studies:** Bằng chứng người thật, việc thật.
7. **The Offer Stack:** Bảng giá trị chi tiết từng phần.
8. **Risk Reversal:** Chính sách bảo hành rõ ràng, an tâm tuyệt đối.
9. **FAQ:** Trả lời trực diện 5-7 thắc mắc cản trở việc mua hàng.
10. **Final CTA:** Lời kêu gọi hành động cuối cùng trước khi hết hạn.
