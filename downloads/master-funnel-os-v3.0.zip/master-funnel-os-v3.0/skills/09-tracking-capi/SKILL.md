---
name: funnel-tracking-capi
description: Cài đặt Meta Pixel kết hợp Server-side Conversions API (CAPI) đo lường chính xác hiệu quả quảng cáo.
---

# SKILL: FULL-FUNNEL TRACKING & CONVERSIONS API

## 🎯 Mục Tiêu
Đo lường chính xác 100% các sự kiện chuyển đổi từ lúc xem trang đến lúc thanh toán thành công, bất chấp các trình chặn quảng cáo.

## 📋 Danh Mục Sự Kiện Cần Đo
- `PageView`: Khi khách tải trang.
- `Lead`: Khi khách bấm gửi form thông tin.
- `InitiateCheckout`: Khi pop-up mã QR thanh toán mở ra.
- `Purchase`: Khi webhook ngân hàng xác nhận tiền đã vào tài khoản (gửi qua CAPI kèm `event_id` duy nhất).
