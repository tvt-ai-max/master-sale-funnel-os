---
name: funnel-ui-components
description: Sinh mã nguồn HTML và Tailwind CSS sạch, chuẩn responsive cho từng Section của Landing Page.
---

# SKILL: TAILWIND UI COMPONENT BUILDER

## 🎯 Mục Tiêu
Chuyển hóa bản copy thành mã nguồn HTML/Tailwind CSS tinh gọn, tải nhanh và hiển thị tối ưu trên cả Mobile lẫn Desktop.

## 📋 Nguyên Tắc Kỹ Thuật
- Ưu tiên Mobile-First (`w-full px-4 md:px-8 max-w-6xl mx-auto`).
- Không dùng CSS inline lộn xộn, chỉ sử dụng utility classes chuẩn của Tailwind CSS.
- Đảm bảo độ tương phản màu chữ với màu nền đạt chuẩn WCAG AA ($\ge 4.5:1$).
