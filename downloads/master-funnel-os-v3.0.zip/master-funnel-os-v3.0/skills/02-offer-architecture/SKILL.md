---
name: funnel-offer-architecture
description: Thiết kế cấu trúc Grand Slam Offer, xây dựng thang giá trị (Value Ladder) và gói quà tặng Bonus Stack.
---

# SKILL: GRAND SLAM OFFER ARCHITECTURE

## 🎯 Mục Tiêu
Tạo ra một lời đề nghị giá trị cao đến mức khách hàng cảm thấy ngớ ngẩn nếu từ chối (Grand Slam Offer).

## 📋 4 Yếu Tố Tạo Nên Offer Chuyển Đổi Cao
$$\text{Giá Trị Offer} = \frac{\text{Dream Outcome} \times \text{Perceived Likelihood of Achievement}}{\text{Time Delay} \times \text{Effort & Sacrifice}}$$

1. **Sản phẩm cốt lõi (Core Product):** Giải pháp giải quyết vấn đề chính.
2. **Bộ quà tặng bổ trợ (Bonus Stack):** Giải quyết các vấn đề phát sinh tiếp theo.
3. **Đảo ngược rủi ro (Risk Reversal):** Cam kết hoàn tiền hoặc hỗ trợ đến khi ra kết quả.
4. **Yếu tố thúc đẩy hành động (Urgency & Scarcity):** Giới hạn thời gian hoặc số lượng.
