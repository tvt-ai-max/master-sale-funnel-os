---
name: funnel-chatbot-flows
description: Xây dựng kịch bản Chatbot đa kênh tự động trả lời, phân loại lead và điều hướng vào phễu.
---

# SKILL: MULTI-CHANNEL SOCIAL CHATBOT

## 🎯 Mục Tiêu
Tự động hóa tin nhắn trên Fanpage Facebook, Instagram Direct và TikTok để kéo traffic vào Landing Page.

## 📋 Các Luồng Chat Cần Thiết
1. **Luồng Comment to Inbox:** Khách bình luận từ khóa $ightarrow$ Bot tự động gửi link Landing Page vào tin nhắn.
2. **Luồng FAQ Tự Động:** Giải đáp nhanh giá bán, thời gian diễn ra và hình thức nhận tài liệu.
