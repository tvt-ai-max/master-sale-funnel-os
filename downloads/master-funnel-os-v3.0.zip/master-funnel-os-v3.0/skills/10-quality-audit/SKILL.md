---
name: funnel-quality-audit
description: Bảng kiểm tra 8 điểm chất lượng nghiêm ngặt trước khi xuất bản và chạy chiến dịch quảng cáo.
---

# SKILL: 8-POINT QUALITY AUDIT GATE

## 🎯 Mục Tiêu
Loại bỏ hoàn toàn các lỗi kỹ thuật, lỗi hiển thị hoặc lỗi luồng dữ liệu trước khi đẩy traffic thật vào phễu.

## 📋 8 Tiêu Chí Đánh Giá Pass / Fail
1. Giao diện Mobile hoàn hảo, không lỗi vỡ khung.
2. Tốc độ tải trang dưới 2 giây.
3. Form nhập liệu chặn đứng số điện thoại sai định dạng.
4. Mã VietQR hiển thị đúng số tài khoản và cú pháp đơn hàng.
5. Webhook ngân hàng kích hoạt ổn định.
6. Email xác thực SPF/DKIM không bị rơi vào Spam.
7. Sự kiện Pixel và CAPI đồng bộ chính xác `event_id`.
8. Copy mượt mà, không dùng từ sáo rỗng, chuẩn phong cách thương hiệu.
