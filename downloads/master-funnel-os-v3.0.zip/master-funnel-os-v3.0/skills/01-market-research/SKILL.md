---
name: funnel-market-research
description: Thu thập dữ liệu đối thủ, đào sâu insight khách hàng mục tiêu và phân tích điểm nghẽn thị trường.
---

# SKILL: MARKET & COMPETITOR RESEARCH

## 🎯 Mục Tiêu
Bóc tách chân dung khách hàng lý tưởng (ICP), xác định 5 nỗi đau lớn nhất và tìm ra lỗ hổng của các giải pháp đối thủ hiện có trên thị trường.

## 📋 Các Bước Thực Thi
1. **Định danh tệp khách hàng:** Xác định ngành nghề, quy mô, ngân sách và mục tiêu cốt lõi.
2. **Đào sâu nỗi đau (Pain Points):**
   - Vấn đề họ đang gặp phải hàng ngày là gì?
   - Họ đã thử giải pháp nào và vì sao không hiệu quả?
   - Cảm xúc tiêu cực khi vấn đề không được giải quyết (mất tiền, stress, tốn thời gian).
3. **Kết quả mong ước (Dream Outcome):** Trạng thái lý tưởng sau khi áp dụng giải pháp.
4. **Đề xuất góc tiếp cận độc bản (Hook):** Tạo thông điệp 1 câu đánh trúng tâm lý.
