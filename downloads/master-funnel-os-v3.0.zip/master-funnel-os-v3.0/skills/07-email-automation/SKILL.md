---
name: 07-email-automation
description: Thiết kế và vận hành chuỗi Email Funnel Kép (Unpaid Nurturing & Paid Onboarding/Upsell) kết nối Supabase và Resend API chuẩn toilatungplatform.
---

# 📧 SUB-SKILL 07: DUAL EMAIL FUNNEL & RESEND AUTOMATION ENGINE

## 🎯 1. MỤC TIÊU & KIẾN TRÚC FUNNEL KÉP (THE DUAL-LADDER SYSTEM)

Hệ thống Email Funnel được thiết kế theo mô hình **Dual-Ladder Transition Gate** chuẩn hóa từ dự án `toilatungplatform` (`toilatung.com/skills`), phân tách rõ ràng 2 luồng hành vi khách hàng:

```
                               ┌─────────────────────────────┐
                               │  Khách Điền Form (Sale Page)│
                               └──────────────┬──────────────┘
                                              │
                     ┌────────────────────────┴────────────────────────┐
                     ▼                                                 ▼
      [CHƯA CHUYỂN KHOẢN]                                   [ĐÃ CHUYỂN KHOẢN 386K]
   master-funnel-v3-unpaid                                  master-funnel-v3-paid
  ┌─────────────────────────────┐                        ┌─────────────────────────────┐
  │ Step 1 (Day 0): Giữ chỗ VietQR│                       │ Step 1 (Day 0): Tải 60 Files│
  │ Step 2 (Day 1): Anti AI Slop│                        │ Step 2 (Day 1): 3 Bước Setup│
  │ Step 3 (Day 3): 6 Presets CS│  ──(SePay Webhook)──>  │ Step 3 (Day 3): 30-Pt Audit │
  │ Step 4 (Day 5): Hạn Chót 386k│ (HỦY UNPAID, BẬT PAID)│ Step 4 (Day 7): Upsell 16 AI│
  └─────────────────────────────┘                        └─────────────────────────────┘
```

---

## 📋 2. CHI TIẾT 2 NHÁNH FUNNEL (KỊCH BẢN & SUBJECT LINES)

### 🔴 NHÁNH 1: UNPAID FUNNEL (`master-funnel-v3-unpaid`)
*Mục tiêu: Xử lý trì hoãn, giải thích Director Mindset, chứng minh giá trị qua 6 Presets và chốt đơn 386k.*

1. **Step 1 (Day 0 - Ngay khi mở popup QR):**
   - **Subject:** `⏳ [Giữ Chỗ 386k] Hướng dẫn nhận Bộ Khung Master Sale Funnel OS v3.0`
   - **Nội dung:** Thông tin chuyển khoản MB Bank `0912210457`, cú pháp `TVT [SĐT]`, quà tặng tóm tắt 10 Sub-Skills.
2. **Step 2 (Day 1 - Sau 24 giờ):**
   - **Subject:** `Director Mindset: Tại sao 95% phễu bán hàng hiện nay bị dính 'AI Slop'?`
   - **Nội dung:** Phân tích bẫy AI cẩu thả vs Kiến trúc 3 lớp (Harness - Graph - Loop), kêu gọi lấy 60 file.
3. **Step 3 (Day 3 - Sau 72 giờ):**
   - **Subject:** `Case Study: Triển khai phễu bán hàng đa ngành trong 3 giờ thay vì 3 tuần`
   - **Nội dung:** Bóc tách 6 Presets (SaaS, Spa, BĐS, Agency), demo lệnh điều khiển Hermes CLI.
4. **Step 4 (Day 5 - Sau 120 giờ):**
   - **Subject:** `⚠️ Cơ hội cuối: Suất chuyển nhượng 386.000đ sắp đóng lại`
   - **Nội dung:** Cảnh báo giới hạn 100 suất, cam kết chất lượng thực chiến 100% và quyền sử dụng vĩnh viễn không giới hạn dự án.

---

### 🟢 NHÁNH 2: PAID FUNNEL (`master-funnel-v3-paid`)
*Mục tiêu: Bàn giao toàn bộ tài sản kỹ thuật, hướng dẫn 1-Click setup, kích hoạt 30-Point Audit và Upsell dịch vụ Thuê 16 Nhân Sự AI.*

1. **Step 1 (Day 0 - Tức thì sau 10 giây SePay Webhook):**
   - **Subject:** `🎉 [TẢI VỀ NGAY] Trọn bộ 60 Tệp Mã Nguồn Enterprise Master Funnel & Hermes Agent v3.0`
   - **Nội dung:** Link Google Drive Master, GitHub repo, video hướng dẫn 1-Click `install.sh`/`install.bat`.
2. **Step 2 (Day 1 - Sau 24 giờ):**
   - **Subject:** `Lộ trình 3 bước khởi động cỗ máy Sale Funnel đầu tiên trong 3 giờ`
   - **Nội dung:** Hướng dẫn sửa file YAML cấu hình, chạy Sub-Skill 03 Copywriting tự động.
3. **Step 3 (Day 3 - Sau 72 giờ):**
   - **Subject:** `Checklist 30-Point Audit Gate: Bí quyết kiểm thử chất lượng trước khi ra mắt`
   - **Nội dung:** Hướng dẫn chạy file kiểm toán tự động, tối ưu LCP < 1.2s và đối soát CAPI.
4. **Step 4 (Day 7 - Sau 7 ngày):**
   - **Subject:** `Đòn bẩy tiếp theo: Bạn đã sẵn sàng thuê 16 Nhân Sự AI vận hành phễu 24/7?`
   - **Nội dung:** Giới thiệu dịch vụ Cho Thuê Nhân Sự AI Enterprise tại `lexioperator.com/nhan-su-ai` (1.8M/tháng) và mời đăng ký tư vấn chiến lược 1-1 với Nguyễn Thanh Tùng.

---

## ⚙️ 3. CƠ CHẾ SUPABASE + RESEND CRON SCHEDULER

1. **Khi khách nhập form:**
   - Tạo Lead trong bảng `leads` với `fields = { paymentStatus: 'pending', productId: 'master-funnel-v3' }`.
   - Tạo Invoice trong bảng `invoices` với `status = 'pending'`, `transfer_content = 'TVT [PHONE]'`.
   - Chèn dòng `email_sequences` (Step 1, `status = 'pending'`, `scheduled_at = NOW()`).
2. **Khi SePay Webhook báo tiền về (386.000đ):**
   - Cập nhật Lead `paymentStatus = 'paid'` & Invoice `status = 'paid'`.
   - Xóa toàn bộ pending emails của `master-funnel-v3-unpaid`.
   - Chèn dòng `email_sequences` (Step 1, `source = 'master-funnel-v3-paid'`, `scheduled_at = NOW()`).
3. **Cron Job hàng ngày / hàng giờ (`cron_email_drip.py`):**
   - Quét các email `status = 'pending' AND scheduled_at <= NOW()`.
   - Gửi email qua Resend Multi-tenant API (`contact@toilatung.com`).
   - Cập nhật `status = 'sent'` và tự động tính `scheduled_at` cho Step kế tiếp.
