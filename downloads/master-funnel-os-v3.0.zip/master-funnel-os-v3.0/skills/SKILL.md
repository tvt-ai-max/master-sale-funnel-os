---
name: skill-sale-funnel-master
description: Quy trình tổng thể xây dựng Sale Funnel chuyển đổi cao và Marketing Automation bằng AI Agent từ A đến Z.
---

# SKILL-SALE-FUNNEL MASTER PLAYBOOK

## 🎯 MỤC TIÊU
Hướng dẫn toàn bộ quy trình xây dựng, thiết kế, triển khai và tự động hóa hệ thống Sale Funnel chuyển đổi cao, tích hợp cổng thanh toán VietQR và Automation đa kênh bằng lực lượng AI Agent.

## 🔄 QUY TRÌNH 5 GIAI ĐOẠN BẮT BUỘC
1. **Giai đoạn 1: Nghiên cứu & Định vị Offer** (`skills/01-market-research`, `skills/02-offer-architecture`)
2. **Giai đoạn 2: Biên soạn nội dung chuyển đổi** (`skills/03-copywriting`)
3. **Giai đoạn 3: Thiết kế UI & Mã nguồn HTML/Tailwind** (`skills/04-design-dna`, `skills/05-ui-components`)
4. **Giai đoạn 4: Cổng thanh toán & Tự động hóa** (`skills/06-form-checkout`, `skills/07-email-automation`, `skills/08-chatbot-flows`)
5. **Giai đoạn 5: Tracking & Kiểm toán chất lượng** (`skills/09-tracking-capi`, `skills/10-quality-audit`)

## 🛡️ NGUYÊN TẮC BẤT BIẾN
- Không sinh toàn bộ phễu trong 1 lần. Phân rã theo từng Section.
- Bắt buộc kiểm tra độ tương thích Mobile trước khi nghiệm thu.
- Tự động hóa phải có cơ chế đối soát chống trùng lặp dữ liệu.
