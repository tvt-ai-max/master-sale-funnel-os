---
name: funnel-form-checkout
description: Xây dựng form thu lead và popup thanh toán VietQR tự động với mã giao dịch duy nhất.
---

# SKILL: LEAD FORM & VIETQR CHECKOUT INTEGRATION

## 🎯 Mục Tiêu
Tạo trải nghiệm thanh toán quét mã QR trong 5 giây, tự động nhận diện giao dịch và chuyển hướng khách hàng.

## 📋 Các Bước Triển Khai
1. **Form thu thập thông tin:** Trường Tên, Số điện thoại, Email.
2. **Sinh mã VietQR Động:**
   - Cú pháp: `https://img.vietqr.io/image/{BANK_ID}-{ACCOUNT_NO}-compact2.png?amount={AMOUNT}&addInfo={ORDER_ID}&accountName={ACCOUNT_NAME}`
3. **Xử lý Webhook Biến Động Số Dư:** Đối soát `ORDER_ID` và cập nhật trạng thái đơn hàng.
