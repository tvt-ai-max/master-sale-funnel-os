---
name: funnel-design-dna
description: Tạo lập và duy trì tệp Design.md nhằm kiểm soát bảng màu, typography, khoảng cách và style thị giác.
---

# SKILL: DESIGN DNA & SPECIFICATION

## 🎯 Mục Tiêu
Đóng gói quy chuẩn thiết kế thành file `Design.md` duy nhất để mọi khối giao diện do AI tạo ra đều đồng bộ và không bị "AI Slop".

## 📋 Các Thông Số Quy Chuẩn
- **Color Palette:** 1 Màu chủ đạo (Primary), 1 Màu hành động (Accent/CTA), 2 Màu nền (Light/Dark neutral).
- **Typography:** Quy định cụ thể tên font, line-height và font-weight cho H1, H2, H3, Body text.
- **Component Rules:** Bán kính bo góc cố định, độ bóng (box-shadow) tinh tế, khoảng cách padding chuẩn.
