# PRESET 02: THẨM MỸ VIỆN / SPA / CLINIC Y KHOA

## 🎯 ĐẶC TRƯNG NGÀNH
- **Mục tiêu phễu:** Đăng ký nhận Voucher trải nghiệm dịch vụ buổi đầu (Low-barrier offer) hoặc Đặt lịch tư vấn bác sĩ 1-1.
- **Quyết định mua hàng:** Dựa trên cảm xúc khao khát cái đẹp, sự an tâm về trình độ bác sĩ/công nghệ và không gian thư giãn.
- **Phong cách thị giác:** Sang trọng, trang nhã, nhẹ nhàng, sạch sẽ chuẩn y khoa.

## 🎨 PALETTE MÀU & TYPOGRAPHY
- Primary: `#3E2723` (Nâu Đất Sang Trọng) hoặc `#1A365D` (Navy Y Khoa)
- Accent / CTA: `#C5A880` (Champagne Gold) hoặc `#D97706` (Warm Amber)
- Neutral Background: `#FAF8F5` (Kem Sữa Ấm) / `#FFFFFF`
- Font: `Playfair Display` (Tiêu đề) + `Inter` / `Montserrat` (Thân bài)

## 📑 CẤU TRÚC PHỄU CHUYỂN ĐỔI CHUẨN
1. **Hero:** Hình ảnh không gian sang trọng hoặc bác sĩ chuyên khoa + Voucher ưu đãi 70% buổi trải nghiệm đầu tiên.
2. **Vấn đề & Nỗi đau:** Tự ti về làn da/vóc dáng, đã thử nhiều nơi nhưng bị tái phát hoặc đau đớn.
3. **Cơ chế công nghệ mới:** Giới thiệu công nghệ điều trị độc quyền được chuyển giao chính hãng.
4. **Đội ngũ bác sĩ:** Hình ảnh, bằng cấp và số năm kinh nghiệm của bác sĩ trực tiếp thăm khám.
5. **Before / After Real Cases:** Ảnh chụp thực tế không qua chỉnh sửa ảo + Feedback video của khách.
6. **Quy trình 5 bước chuẩn y khoa:** Thăm khám $\rightarrow$ Soi da $\rightarrow$ Lên phác đồ $\rightarrow$ Điều trị $\rightarrow$ Chăm sóc tại nhà.
7. **Form Đặt Lịch & Giữ Chỗ:** Form chọn ngày giờ khám + Quét QR cọc 99k/199k giữ suất ưu đãi.
