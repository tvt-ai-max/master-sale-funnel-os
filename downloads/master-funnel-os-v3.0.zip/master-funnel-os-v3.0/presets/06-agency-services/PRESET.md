# PRESET 06: B2B PROFESSIONAL SERVICES & AGENCY

## 🎯 ĐẶC TRƯNG NGÀNH
- **Mục tiêu phễu:** Đăng ký nhận Bản Đánh Giá Miễn Phí (Free Audit Call), Đặt lịch tư vấn chiến lược 1-1.
- **Quyết định mua hàng:** Dựa trên năng lực chuyên môn thực chiến, case study ngành tương tự và phương pháp luận độc quyền.
- **Phong cách thị giác:** Chuyên sâu, tinh gọn, uy tín, thể hiện tư duy hệ thống.

## 🎨 PALETTE MÀU & TYPOGRAPHY
- Primary: `#0B0F19` (Dark Navy Black)
- Accent / CTA: `#4F46E5` (Indigo Chuyên Gia) hoặc `#0284C7` (Sky Blue)
- Background: `#FFFFFF` / `#F8FAFC`
- Font: `Inter`, `Space Grotesk` hoặc `Plus Jakarta Sans`

## 📑 CẤU TRÚC PHỄU CHUYỂN ĐỔI CHUẨN
1. **Hero:** Lời cam kết tăng trưởng (Doanh thu / Lead) + Nút "Đăng ký nhận báo cáo Audit 0đ".
2. **Khách hàng tiêu biểu & Kết quả:** Số liệu tăng trưởng cụ thể của các dự án đã thực thi.
3. **Vấn đề của mô hình cũ:** Agency truyền thống làm việc chậm chạp, báo cáo hình thức, không cam kết doanh số.
4. **Phương pháp luận độc quyền (Framework):** Trình bày quy trình 4 giai đoạn bằng sơ đồ trực quan.
5. **Bảng so sánh năng lực:** Tự làm vs Thuê Agency truyền thống vs Hợp tác cùng chúng tôi.
6. **Case Studies chi tiết:** Bóc tách 1 case study cụ thể từ Điểm bắt đầu $\rightarrow$ Giải pháp triển khai $\rightarrow$ Doanh thu đột phá.
7. **Form Đăng Ký Thẩm Định Năng Lực:** Khách hàng điền thông tin website, ngân sách và chọn lịch hẹn tư vấn.
