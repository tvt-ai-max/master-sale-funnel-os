# PRESET 04: BẤT ĐỘNG SẢN & TÀI CHÍNH ĐẦU TƯ

## 🎯 ĐẶC TRƯNG NGÀNH
- **Mục tiêu phễu:** Tải Trọn Bộ Tài Liệu Quy Hoạch & Bảng Giá Gốc, Đăng Ký Chuyến Tham Quan Thực Tế (Site Tour VIP).
- **Quyết định mua hàng:** Dựa trên phân tích khả năng sinh lời, uy tín chủ đầu tư, pháp lý hoàn chỉnh và vị trí đắc địa.
- **Phong cách thị giác:** Đẳng cấp, thượng lưu, vững chãi, hình ảnh flycam / 3D phối cảnh sắc nét.

## 🎨 PALETTE MÀU & TYPOGRAPHY
- Primary: `#064E3B` (Xanh Emerald Quý Tộc) hoặc `#111827` (Đen Sang Trọng)
- Accent / CTA: `#D97706` (Vàng Gold Kim Hoàng Gia)
- Background: `#FAFAF9` (Stone Light) / `#FFFFFF`
- Font: `Cinzel` / `Playfair Display` (Tiêu đề) + `Inter` (Thân bài)

## 📑 CẤU TRÚC PHỄU CHUYỂN ĐỔI CHUẨN
1. **Hero:** Toàn cảnh flycam dự án + Headline khẳng định tiềm năng tăng giá / đòn bẩy hạ tầng.
2. **Thông số dự án độc bản:** Vị trí vàng, quy mô, mật độ xây dựng, pháp lý sổ hồng 100%.
3. **Bản đồ liên kết vùng:** Kết nối giao thông trọng điểm trong bán kính 5-15 phút.
4. **Tiện ích nội khu chuẩn Resort:** Bể bơi vô cực, công viên trung tâm, bến du thuyền, trung tâm thương mại.
5. **Bảng phân tích tiềm năng tăng giá (ROI):** So sánh giá khu vực và các cột mốc hạ tầng sắp khánh thành.
6. **Mặt bằng căn hộ & Thiết kế 3D:** Khách hàng có thể bấm xem từng layout căn.
7. **Form Đăng Ký Tải Bảng Giá Đợt 1:** Tải bảng hàng ngoại giao độc quyền + Nhận vé VIP tham quan xe đưa đón.
