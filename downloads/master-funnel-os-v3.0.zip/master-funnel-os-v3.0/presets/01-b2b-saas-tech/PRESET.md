# PRESET 01: B2B SAAS / TECH / SOFTWARE

## 🎯 ĐẶC TRƯNG NGÀNH
- **Mục tiêu phễu:** Đăng ký dùng thử (Free Trial), Đặt lịch Demo 1-1, hoặc Trải nghiệm Sandbox trực tiếp.
- **Quyết định mua hàng:** Dựa trên logic, tính toán ROI, bảo mật dữ liệu và khả năng tích hợp hệ thống.
- **Phong cách thị giác:** Chuyên nghiệp, hiện đại, tối giản, sử dụng các minh họa Mockup UI / Dashboard sắc nét.

## 🎨 PALETTE MÀU & TYPOGRAPHY
- Primary: `#0F172A` (Deep Slate)
- Secondary / Brand: `#2563EB` (Royal Blue)
- Accent / CTA: `#10B981` (Emerald Green) hoặc `#3B82F6` (Electric Blue)
- Background: `#FFFFFF` (White) / `#F8FAFC` (Slate 50)
- Font: `Inter` hoặc `Plus Jakarta Sans`

## 📑 CẤU TRÚC PHỄU CHUYỂN ĐỔI CHUẨN
1. **Hero:** Dashboard preview tương tác + Headline nêu rõ số giờ hoặc chi phí tiết kiệm được.
2. **Logo Cloud:** Các doanh nghiệp / đối tác uy tín đang sử dụng.
3. **Problem & Friction:** Sự rời rạc của các công cụ cũ, thất thoát dữ liệu.
4. **Interactive Feature Breakdown:** Tab chuyển đổi giữa các tính năng chính kèm ảnh gif/video quay màn hình.
5. **Security & Compliance Badges:** SOC2, ISO 27001, GDPR, SSL Encryption.
6. **ROI Calculator:** Bảng tính nhanh số tiền tiết kiệm được khi sử dụng phần mềm.
7. **Pricing Tier:** Bảng giá 3 cột (Starter - Pro - Enterprise) kèm nút "Bắt đầu dùng thử miễn phí".
8. **Final CTA:** Form đặt lịch demo 1-1 với chuyên gia giải pháp.
