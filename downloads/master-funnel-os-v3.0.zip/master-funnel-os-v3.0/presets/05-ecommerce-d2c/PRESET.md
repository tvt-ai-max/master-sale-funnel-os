# PRESET 05: E-COMMERCE & D2C BRANDS

## 🎯 ĐẶC TRƯNG NGÀNH
- **Mục tiêu phễu:** Mua ngay (Direct Checkout), Mua theo Combo tiết kiệm, hoặc Tham gia chương trình Khách hàng thân thiết.
- **Quyết định mua hàng:** Thúc đẩy bởi hình ảnh sản phẩm bắt mắt, ưu đãi giới hạn, đánh giá thực tế và chính sách đổi trả dễ dàng.
- **Phong cách thị giác:** Tươi sáng, hiện đại, kích thích thị giác, nhấn mạnh vào chi tiết sản phẩm.

## 🎨 PALETTE MÀU & TYPOGRAPHY
- Primary: `#18181B` (Zinc 900)
- Accent / CTA: `#DC2626` (Đỏ Mua Sắm) hoặc `#16A34A` (Xanh Lá Khuyến Mãi)
- Background: `#FFFFFF` (Trắng Tinh Khiết) / `#F4F4F5`
- Font: `Inter` hoặc `Plus Jakarta Sans`

## 📑 CẤU TRÚC PHỄU CHUYỂN ĐỔI CHUẨN
1. **Hero:** Ảnh Hero Shot sản phẩm 3D / Đang sử dụng thực tế + Giá ưu đãi gạch ngang + Đánh giá 5 sao.
2. **USP Highlight:** 3 điểm khác biệt lớn nhất so với hàng trôi nổi ngoài thị trường.
3. **Chi tiết cấu tạo / Chất liệu cao cấp:** Ảnh zoom cận cảnh chất liệu, chứng nhận an toàn.
4. **Combo Khuyến Mãi (Bundle Tier):** Mua 1 (Giá thường) vs Mua 2 (Giảm 20% + Free Ship) vs Mua 3 (Tặng 1).
5. **User Generated Content (UGC):** Ảnh khách hàng chụp thực tế đính kèm đánh giá chi tiết.
6. **Cam kết dịch vụ:** Giao hàng hỏa tốc, Kiểm tra hàng trước khi thanh toán, Đổi mới trong 7 ngày.
7. **Form Mua Hàng Nhanh 1-Click:** Chọn size/màu + Điền địa chỉ + Quét VietQR hoặc COD.
