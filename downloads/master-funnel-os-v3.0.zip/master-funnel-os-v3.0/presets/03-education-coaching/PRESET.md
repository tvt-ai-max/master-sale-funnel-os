# PRESET 03: GIÁO DỤC / ĐÀO TẠO / KHÓA HỌC / COACHING

## 🎯 ĐẶC TRƯNG NGÀNH
- **Mục tiêu phễu:** Tham gia Workshop 3-5 ngày (Low-ticket), xem Webinar tự động hoặc Đăng ký phỏng vấn Coaching 1-1 (High-ticket).
- **Quyết định mua hàng:** Tin tưởng vào chuyên gia (Authority), khát khao thành công nhanh và có lộ trình cầm tay chỉ việc rõ ràng.
- **Phong cách thị giác:** Năng động, thu hút, tràn đầy năng lượng hành động.

## 🎨 PALETTE MÀU & TYPOGRAPHY
- Primary: `#1E3A8A` (Xanh Đậm Tri Thức) hoặc `#0F172A` (Slate Đen)
- Accent / CTA: `#EA580C` (Cam Năng Lượng) hoặc `#F59E0B` (Vàng Rực Rỡ)
- Background: `#FFFFFF` / `#F1F5F9`
- Font: `Inter`, `Be Vietnam Pro` hoặc `Roboto`

## 📑 CẤU TRÚC PHỄU CHUYỂN ĐỔI CHUẨN
1. **Hero:** Hook kết quả cụ thể ("Tự xây hệ thống X trong 3 ngày") + Đồng hồ đếm ngược + Nút đăng ký.
2. **Thực trạng ngành:** Chỉ trích cách học lý thuyết suông, học xong không biết làm.
3. **Lộ trình từng ngày (Curriculum):** Chi tiết kết quả cụ thể đạt được sau mỗi buổi học (Không ghi chung chung).
4. **Bộ quà tặng khổng lồ (Bonus Stack):** Toàn bộ template, prompt, mã nguồn, tài liệu đi kèm (Giá trị quy đổi cao).
5. **Hồ sơ giảng viên / Chuyên gia:** Kết quả thực tế, hành trình từ số 0, các dự án đã trực tiếp thực thi.
6. **Testimonial học viên khóa trước:** Video phỏng vấn, tin nhắn khoe kết quả thực tế.
7. **Chính sách hoàn tiền 100%:** Cam kết hoàn tiền vô điều kiện sau buổi học đầu tiên nếu không hài lòng.
8. **Checkout Form:** Quét mã VietQR nhận tài khoản lớp học tự động tức thì.
