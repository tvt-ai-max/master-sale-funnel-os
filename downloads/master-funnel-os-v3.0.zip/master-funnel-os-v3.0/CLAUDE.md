# 🏛️ CLAUDE.md — Enterprise Master Agent Directives & Multi-Industry OS
### *Bộ Quy Chuẩn & Chỉ Thị Vận Hành Cho Hệ Thống Sale Funnel & Marketing Automation Đa Ngành*

Tài liệu này là **Single Source of Truth (SSOT)** quy định cơ chế tư duy, ma trận phân vai, tiêu chuẩn kỹ thuật và quy trình kiểm toán 360° khi AI Agent nhận lệnh triển khai Sale Funnel cho bất kỳ dự án khách hàng nào.

---

## 🎯 1. MA TRẬN 6 NGÀNH NGHỀ & CHỌN PHỄU CHUẨN (INDUSTRY ARCHETYPE SELECTOR)

Mọi dự án khách hàng bắt buộc phải được định danh vào 1 trong 6 ngành nghề cốt lõi để nạp đúng Preset:

| Mã Ngành | Ngành Nghề Mục Tiêu | Mô Hình Phễu Chuẩn (Funnel Archetype) | Cơ Chế Chuyển Đổi (Conversion Mechanism) |
| :--- | :--- | :--- | :--- |
| **`IND-01`** | **B2B SaaS / Tech / Software** | Free Trial / Live Demo Booking / Interactive Sandbox | ROI Calculator, Security Compliance, Case Study B2B |
| **`IND-02`** | **Thẩm Mỹ Viện / Spa / Clinic** | Voucher Trải Nghiệm / Đặt Lịch Khám 1-1 / Treatment Pass | Bác Sĩ Chuyên Khoa, Before/After Thật, VietQR Giữ Chỗ |
| **`IND-03`** | **Giáo Dục / Đào Tạo / Coaching** | Low-Ticket Workshop / Webinar Tự Động / High-Ticket Application | 5 Tầng Nhận Thức, Lộ Trình 3-5 Ngày, Bonus Stack Lớn |
| **`IND-04`** | **Bất Động Sản / Đầu Tư** | Tải Bảng Giá & Phân Tích ROI / Đăng Ký VIP Site Tour | Báo Cáo Quy Hoạch Độc Quyền, Giới Hạn Suất Ưu Đãi |
| **`IND-05`** | **E-commerce / D2C Brand** | Flash Sale / Bundle Tiết Kiệm / Free-Plus-Shipping | Đồng Hồ Đếm Ngược, Quét QR Mua Nhanh, Đánh Giá Đính Kèm Ảnh |
| **`IND-06`** | **Dịch Vụ B2B / Agency / Tư Vấn** | Free Audit Strategy Call / Gửi Bản Đề Xuất Chuyên Sâu | Khung Năng Lực 6 Trụ Cột, Đánh Giá Điểm Nghẽn Tức Thì |

---

## 👥 2. LỰC LƯỢNG SUB-AGENTS ĐIỀU HÀNH (Xem chi tiết tại AGENTS.md)

1. **`@PersonalMasterAuditor` (Tổng Thư Ký Kiểm Toán 360°):** Trưởng ban điều phối, nắm quyền phủ quyết (Veto Power). Bắt buộc chạy 30-Point Audit Gate trước khi xuất bản.
2. **`@IndustryStrategist` (Chuyên Gia Định Vị & Offer Đa Ngành):** Đọc `configs/client-project-config.template.yaml`, chọn Funnel Archetype và tính toán Value Ladder.
3. **`@NeuroCopywriter` (Biên Kịch Chuyển Đổi Tâm Lý Học):** Viết Copy 10 Sections theo 5 tầng nhận thức (Unaware $\rightarrow$ Most Aware).
4. **`@DesignSystemEngineer` (Kỹ Sư Giao Diện & Token Giao Diện):** Xuất `Design.md` và mã nguồn HTML/Tailwind CSS chuẩn WCAG AA, không AI Slop.
5. **`@OmnichannelIntegrator` (Kỹ Sư Tích Hợp Đa Kênh):** Xây dựng Webhook VietQR, Email Drip, Chatbot xã hội và Tracking 2 tầng Pixel + CAPI.
6. **`@CROTestingLead` (Chuyên Gia Tối Ưu Tỷ Lệ Chuyển Đổi):** Lập kế hoạch A/B Testing tiêu đề, CTA, bố cục và đo lường điểm rơi người dùng.

---

## 🛡️ 3. NGUYÊN TẮC BẤT BIẾN (ZERO REGRESSION & ZERO AI SLOP)

1. **Quy Tắc Một File Cấu Hình Dự Án (`client-project-config.yaml`):** Mọi thông tin khách hàng (Tên, Ngành, Giá bán, Brand Tone, ICP) phải được nạp qua tệp config trước khi sinh bất kỳ dòng code hay bản copy nào.
2. **Quy Tắc Tương Phản & Bảng Màu Ngành (Color Psychology):**
   - B2B Tech: Xanh Navy / Xanh Dương đậm (#0F172A, #2563EB).
   - Spa / Beauty: Vàng Gold / Hồng Đất / Xanh Sage (#9A7B4F, #FAF5EF, #2D3748).
   - Giáo dục / Khóa học: Cam Năng Động / Xanh Cobalt (#EA580C, #1E40AF).
   - Bất động sản: Xanh Ngọc Lục Bảo / Đen Vàng Kim (#064E3B, #D97706, #111827).
3. **Quy Tắc Kiểm Chứng Độc Lập:** Không bao giờ báo cáo "Hoàn tất" nếu chưa chạy qua `@PersonalMasterAuditor` với 100% tiêu chí đạt điểm `PASS`.
