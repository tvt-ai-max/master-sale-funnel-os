# 🚀 SKILL-SALE-FUNNEL: Hệ Thống Xây Dựng Sale Funnel & Automation Cùng AI Agent
### *Master Architecture & Operational Execution Package*

Gói kỹ năng và tài liệu vận hành này cung cấp toàn bộ quy trình, biểu mẫu và các kỹ năng chuyên môn chuẩn hóa giúp AI Agent phối hợp cùng Operator để nghiên cứu, thiết kế, lập trình và tự động hóa hệ thống **Sale Funnel chuyển đổi cao** từ A đến Z, triệt tiêu hoàn toàn lỗi **"AI Slop"**.

---

## 📂 CẤU TRÚC THƯ MỤC HỆ THỐNG

```
SKILL-SALE-FUNNEL/
├── README.md                      # Hướng dẫn tổng quan & cấu trúc gói
├── CLAUDE.md                      # Chỉ thị vận hành tối cao cho Claude Code / AI Agents
├── AGENTS.md                      # Ma trận 5 Sub-Agents chuyên trách (Architect, Copywriter, Designer, Integrator, Auditor)
├── MEMORY.md                      # Bộ nhớ dự án, quy tắc bất biến & kinh nghiệm tích lũy
├── LOGS.md                        # Nhật ký vận hành & Audit Log
├── infrastructure/              # 🏗️ CỤM HẠ TẦNG AUTOMATION (DOCKER / N8N / SUPABASE / RESEND / TELEGRAM)
│   ├── docker/                    # Docker Compose Full-Stack (n8n, Postgres, Redis, Hermes) & .env
│   ├── n8n-workflows/             # 5 Workflow n8n JSON (VietQR, Lead routing, Drip email, CAPI, Chatbot)
│   ├── supabase/                  # CSDL PostgreSQL Schema (Leads, Orders, Drip logs) & Python Client
│   ├── resend/                    # Multi-Tenant Email Client & Template HTML chuẩn responsive
│   └── telegram/                  # Telegram Bot Dispatcher (Interactive buttons, Alert đơn hàng)
├── hermes-agent/                  # 🤖 BỘ CÀI ĐẶT HERMES AI AGENT ĐỘC LẬP (MÃ NGUỒN PYTHON/DOCKER)
│   ├── README.md                  # Hướng dẫn cài đặt Hermes Agent trên Mac/Win/Linux
│   ├── install.sh / install.bat   # Script tự động cài đặt 1-Click
│   ├── run_agent.py               # Động cơ tương tác CLI với Rich UI & Memory
│   ├── memory_store.py            # SQLite/JSON Long-Term Memory
│   ├── skills_loader.py           # Bộ nạp 10 Sub-Skills & 6 Presets
│   ├── docker-compose.yml         # Container hóa độc lập
│   └── config.template.yaml       # Cấu hình API Keys (Gemini, Claude, GPT, Ollama)
├── .claude/
│   └── settings.json              # Cấu hình môi trường AI Agent
├── skills/                        # 10 Sub-Skills thực thi chuyên sâu
│   ├── SKILL.md                   # Master Skill tổng hợp quy trình từ A - Z
│   ├── 01-market-research/SKILL.md # Skill nghiên cứu thị trường, đối thủ & pain points
│   ├── 02-offer-architecture/SKILL.md # Skill thiết kế Grand Slam Offer & Value Ladder
│   ├── 03-copywriting/SKILL.md    # Skill viết Direct Response Copy 10 Sections
│   ├── 04-design-dna/SKILL.md     # Skill sinh file Design.md chuẩn nhận diện
│   ├── 05-ui-components/SKILL.md  # Skill sinh mã HTML/Tailwind sạch không AI Slop
│   ├── 06-form-checkout/SKILL.md  # Skill tích hợp Form & Dynamic VietQR Payment
│   ├── 07-email-automation/SKILL.md # Skill thiết lập chuỗi Email Drip 3-5 bước
│   ├── 08-chatbot-flows/SKILL.md  # Skill thiết lập Chatbot đa kênh (FB, Insta, TikTok)
│   ├── 09-tracking-capi/SKILL.md  # Skill thiết lập Pixel & Server-side CAPI
│   └── 10-quality-audit/SKILL.md  # Skill 8-Point Pre-Launch Audit Gate
├── templates/                     # Biểu mẫu định dạng chuẩn (SSOT)
│   ├── Design.template.md         # Template Design.md chuẩn nhận diện
│   ├── Offer-Stack.template.md    # Template cấu trúc Offer & Bonus Stack
│   ├── 10-Sections-Copy.template.md # Template khung nội dung 10 sections
│   ├── VietQR-Payload.template.json # Schema Webhook thanh toán chuẩn
│   └── Email-Drip-Sequence.template.md # Template kịch bản 3 email chăm sóc
├── prompts/                       # Thư viện prompt chuẩn cho AI Agent
│   ├── 01-research-prompt.md      # Prompt research đối thủ & insight khách hàng
│   ├── 02-copywriting-prompt.md   # Prompt viết từng section
│   ├── 03-tailwind-ui-prompt.md   # Prompt sinh code UI sạch
│   └── 04-audit-gate-prompt.md    # Prompt kiểm toán 8 điểm
└── checklists/                    # Danh sách kiểm tra nghiệm thu
    ├── pre-launch-audit.md        # Bảng kiểm tra 8 điểm trước khi launch
    └── conversion-optimization.md # Bảng kiểm tra tối ưu tỷ lệ chuyển đổi CRO
```

---

## ⚡ HƯỚNG DẪN BẮT ĐẦU NHANH (QUICKSTART)

1. **Khởi tạo dự án:** Copy `templates/Design.template.md` và `templates/Offer-Stack.template.md` vào thư mục dự án của bạn.
2. **Kích hoạt AI Agent:** Mở terminal trong thư mục này với Claude Code hoặc công cụ AI Agent của bạn.
3. **Thực thi quy trình 3 giai đoạn:**
   - **Giai đoạn 1 (Research & Copy):** Yêu cầu Agent kích hoạt `skills/01-market-research` và `skills/03-copywriting`.
   - **Giai đoạn 2 (UI & Checkout):** Kích hoạt `skills/04-design-dna`, `skills/05-ui-components` và `skills/06-form-checkout`.
   - **Giai đoạn 3 (Automation & Tracking):** Kích hoạt `skills/07-email-automation`, `skills/09-tracking-capi` và chạy `skills/10-quality-audit`.
