# MEMORY.md — Bộ Nhớ Dài Hạn & Tri Thức Thực Chiến Đa Ngành

Tài liệu tích lũy các benchmark chuyển đổi, quy tắc tâm lý màu sắc và các bẫy kỹ thuật đã được tối ưu qua hàng trăm dự án thực tế.

---

## 📊 1. BENCHMARK TỶ LỆ CHUYỂN ĐỔI CHUẨN THEO NGÀNH (CONVERSION BENCHMARKS)

| Ngành Nghề | Landing Page CR (Opt-in) | Sales Page CR (Checkout) | Time on Page Chuẩn | Tỷ Lệ Mở Email (Drip) |
| :--- | :---: | :---: | :---: | :---: |
| **B2B SaaS / Tech** | $12\% - 25\%$ | $3\% - 8\%$ (Trial/Demo) | $2.5 - 4.0\text{ phút}$ | $45\% - 60\%$ |
| **Spa / Clinic / Beauty** | $18\% - 35\%$ | $8\% - 15\%$ (Voucher) | $1.5 - 2.5\text{ phút}$ | $50\% - 65\%$ |
| **Khóa Học / Coaching** | $20\% - 45\%$ (Lead magnet) | $2\% - 6\%$ (Low-ticket) | $3.0 - 6.0\text{ phút}$ | $40\% - 55\%$ |
| **Bất Động Sản** | $8\% - 18\%$ (Bảng giá) | $1.5\% - 3.5\%$ (Site tour) | $2.0 - 3.5\text{ phút}$ | $35\% - 50\%$ |
| **E-commerce / D2C** | $25\% - 40\%$ (Mã giảm giá) | $2.5\% - 5.5\%$ (Mua ngay) | $1.2 - 2.0\text{ phút}$ | $30\% - 45\%$ |
| **Dịch Vụ B2B / Agency** | $10\% - 22\%$ (Audit Call) | $4\% - 10\%$ (Proposal) | $3.0 - 5.0\text{ phút}$ | $50\% - 70\%$ |

---

## 🎨 2. TÂM LÝ HỌC MÀU SẮC THEO NGÀNH (INDUSTRY COLOR PSYCHOLOGY)

1. **B2B SaaS & Tech:**
   - Tone: Uy tín, hiện đại, ổn định.
   - Bảng màu: Xanh Navy `#0F172A`, Xanh Dương `#2563EB`, Trắng `#FFFFFF`, Xám Slate `#64748B`.
2. **Clinic, Spa & Thẩm Mỹ:**
   - Tone: Sang trọng, thư giãn, sạch sẽ, an tâm y khoa.
   - Bảng màu: Vàng Champagne `#C5A880`, Nâu Đất Ấm `#3E2723`, Kem Trắng `#FAF8F5`, Xanh Bạc Hà Y Khoa `#0D9488`.
3. **Giáo Dục, Khóa Học & Phát Triển Bản Thân:**
   - Tone: Năng lượng, truyền cảm hứng, hành động ngay.
   - Bảng màu: Cam Rực Cháy `#EA580C`, Xanh Đậm Tri Thức `#1E3A8A`, Vàng Điểm Nhấn `#F59E0B`.
4. **Bất Động Sản & Tài Chính Đầu Tư:**
   - Tone: Vững chãi, thịnh vượng, đẳng cấp, độc bản.
   - Bảng màu: Xanh Emerald `#064E3B`, Vàng Kim Gold `#D97706`, Đen Quyền Lực `#111827`.
5. **E-commerce & D2C:**
   - Tone: Kích thích mua sắm, sôi động, rõ ràng.
   - Bảng màu: Đỏ Mua Sắm `#DC2626`, Xanh Lá Chuyển Đổi `#16A34A`, Nền Trắng Tinh `#FFFFFF`.

---

## 🛡️ 3. CÁC BẪY KỸ THUẬT PHỔ BIẾN & CÁCH PHÒNG TRÁNH (LESSONS LEARNED)
- **Bẫy 1: Form quá dài làm rớt $50\%$ Lead.** Với B2C/Spa/Khóa học, chỉ xin `Họ Tên` + `Số Điện Thoại`. Chỉ xin thêm ngân sách/nhu cầu đối với B2B High-Ticket.
- **Bẫy 2: VietQR thiếu tự động đối soát.** Cần tích hợp polling realtime hoặc Pusher/WebSocket ở trang thanh toán để khi khách chuyển khoản xong, màn hình tự động chuyển sang trang "Cảm ơn & Hướng dẫn" trong vòng $< 1.5\text{s}$.
- **Bẫy 3: Mất $30\%$ dữ liệu quảng cáo vì thiếu CAPI.** Không dựa vào Browser Pixel đơn thuần. Mọi sự kiện mua hàng phải gửi từ Server-side với độ tin cậy $100\%$.
