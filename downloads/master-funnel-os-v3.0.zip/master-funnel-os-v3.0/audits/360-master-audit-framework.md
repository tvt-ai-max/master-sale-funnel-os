# 🔍 360-DEGREE MASTER AUDIT FRAMEWORK
### *Khung Kiểm Toán Toàn Diện 30 Điểm Trước Khi Xuất Bản & Bơm Traffic*

Toàn bộ phễu phải vượt qua bài kiểm toán này và được `@PersonalMasterAuditor` ký duyệt.

---

## 📑 BẢNG KIỂM TOÁN 30 TIÊU CHÍ (6 KHỐI NGHIỆP VỤ)

### KHỐI 1: CHIẾN LƯỢC ĐỊNH VỊ & OFFER (5 ĐIỂM)
- [ ] 1.1. Tiêu đề H1 có Hook trực diện, nêu rõ kết quả cụ thể đo lường được.
- [ ] 1.2. Thang giá trị (Value Ladder) và Bonus Stack giải quyết trọn vẹn nỗi sợ của khách.
- [ ] 1.3. Có lý do khẩn cấp thực sự (Scarcity / Urgency) chứ không tạo áp lực giả tạo.
- [ ] 1.4. Chính sách bảo hành / đảo ngược rủi ro (Risk Reversal) rõ ràng, tạo an tâm tuyệt đối.
- [ ] 1.5. Phù hợp chính xác với mức độ nhận thức (Awareness Level) của tệp traffic mục tiêu.

### KHỐI 2: CHẤT LƯỢNG NỘI DUNG & ANTI-AI SLOP (5 ĐIỂM)
- [ ] 2.1. Không chứa từ ngữ sáo rỗng, khuôn mẫu của AI ("thần thánh", "đột phá nhất lịch sử").
- [ ] 2.2. Sử dụng cấu trúc ngắt dòng ngắn, có icon/bullet point hỗ trợ đọc lướt (Scan-reading).
- [ ] 2.3. Bằng chứng xã hội (Social Proof) có người thật, số liệu thật, ảnh chụp thực tế.
- [ ] 2.4. Phần FAQ xử lý trực diện ít nhất 5 lời từ chối mua hàng phổ biến nhất.
- [ ] 2.5. Không có bất kỳ lỗi chính tả, ngữ pháp hoặc câu cú lủng củng nào.

### KHỐI 3: THIẾT KẾ UI/UX & TỐI ƯU DI ĐỘNG (5 ĐIỂM)
- [ ] 3.1. Mobile-first: 100% thành phần hiển thị hoàn hảo trên màn hình 375px–430px.
- [ ] 3.2. Không có lỗi tràn ngang trang (No horizontal scroll).
- [ ] 3.3. Độ tương phản chữ với nền đạt chuẩn WCAG AA ($\ge 4.5:1$).
- [ ] 3.4. Khoảng cách giữa các Section thoáng đãng (tối thiểu 48px trên mobile, 64px trên desktop).
- [ ] 3.5. Nút CTA kích thước tối thiểu 48px chiều cao, dễ dàng chạm bằng ngón tay cái trên điện thoại.

### KHỐI 4: HIỆU NĂNG KỸ THUẬT & TỐC ĐỘ (5 ĐIỂM)
- [ ] 4.1. Thời gian tải trang (LCP) dưới 1.8 giây trên đường truyền 4G.
- [ ] 4.2. 100% hình ảnh đã chuyển sang định dạng WebP và được nén tối ưu.
- [ ] 4.3. Mã nguồn HTML/CSS tinh gọn, không nạp thừa các thư viện JavaScript nặng nề.
- [ ] 4.4. Đạt chứng chỉ bảo mật SSL/HTTPS xanh 100%.
- [ ] 4.5. Favicon, OpenGraph Image (OG Image khi share link) hiển thị sắc nét, đúng tỷ lệ 1200x630.

### KHỐI 5: CỔNG THANH TOÁN & WEBHOOK CRM (5 ĐIỂM)
- [ ] 5.1. Form thu thập dữ liệu có kiểm tra định dạng Số điện thoại (10 chữ số) và Email hợp lệ.
- [ ] 5.2. Mã Dynamic VietQR sinh đúng STK ngân hàng, đúng số tiền và kèm mã đơn hàng duy nhất.
- [ ] 5.3. Webhook nhận biến động số dư hoạt động ổn định trong vòng $< 3$ giây.
- [ ] 5.4. Hệ thống tự động chuyển trang cảm ơn sau khi thanh toán thành công.
- [ ] 5.5. Dữ liệu đơn hàng được lưu tức thì vào CRM / Google Sheets / Telegram Alert.

### KHỐI 6: AUTOMATION & TRACKING ĐA TẦNG (5 ĐIỂM)
- [ ] 6.1. Email xác nhận đơn gửi đến khách hàng ngay lập tức (phút 0), không rơi vào Spam (Đã cấu hình DKIM/SPF).
- [ ] 6.2. Chuỗi Email Drip 3-5 bước được cài đặt đúng độ trễ (Delay 24h, 72h).
- [ ] 6.3. Chatbot mạng xã hội kích hoạt đúng từ khóa bình luận/tin nhắn.
- [ ] 6.4. Facebook Pixel kích hoạt đúng các sự kiện: `PageView`, `Lead`, `InitiateCheckout`.
- [ ] 6.5. Meta Conversions API (CAPI) gửi sự kiện `Purchase` từ máy chủ kèm mã `event_id` chống trùng lặp.
