# 🏗️ AUTOMATION & INFRASTRUCTURE STACK
### *Docker • n8n Workflows • Supabase Database • Resend Multi-Tenant • Telegram Bot*

Thư mục này chứa toàn bộ hạ tầng tự động hóa, cơ sở dữ liệu và các đầu nối (connectors) phục vụ việc vận hành Sale Funnel tự động 24/7.

```mermaid
flowchart TD
    Landing["Landing Page / Form Lead"] --> N8N["n8n Automation Engine (Port 5678)"]
    VietQR["VietQR Webhook (Tiền Về)"] --> N8N
    
    N8N --> DB[("Supabase Cloud / PostgreSQL<br/>(Lưu Trữ Lead, Order, Logs)")]
    N8N --> Mail["Resend Multi-Tenant API<br/>(Gửi Email Kích Hoạt & Drip)"]
    N8N --> Tele["Telegram Bot Dispatcher<br/>(Báo Đơn & Alert Sales Team)"]
    N8N --> CAPI["Meta Conversions API (CAPI)<br/>(Bắn Sự Kiện Purchase Server-Side)"]
    N8N --> Hermes["Hermes AI Agent Core<br/>(Xử Lý AI & Tư Vấn 24/7)"]
```

---

## 📂 DANH MỤC THÀNH PHẦN HẠ TẦNG

1. **`docker/`**: Đóng gói cụm container `docker-compose.yml` gồm n8n, PostgreSQL/Supabase Local, Redis, Hermes Agent.
2. **`n8n-workflows/`**: 5 Workflows JSON mẫu sẵn sàng Import 1-Click vào n8n:
   - `01_vietqr_payment_webhook.json`: Xử lý tiền về $ightarrow$ Báo Telegram $ightarrow$ Gửi Mail $ightarrow$ Lưu DB.
   - `02_instant_lead_capture_routing.json`: Thu lead từ Form $ightarrow$ Phân loại $ightarrow$ Gửi Lead Magnet.
   - `03_email_drip_scheduler.json`: Quét lịch gửi chuỗi email chăm sóc Day 1, 3, 5.
   - `04_meta_capi_purchase_dispatcher.json`: Bắn sự kiện chuyển đổi lên Meta CAPI kèm mã băm SHA256.
   - `05_telegram_chatbot_support_flow.json`: Webhook Bot Telegram trả lời tự động cùng Hermes.
3. **`supabase/`**:
   - `schema.sql`: Cấu trúc bảng `crm_leads`, `funnel_orders`, `email_drip_logs`, `chat_conversations`.
   - `supabase_client.py`: Module kết nối và truy vấn CSDL từ Python.
4. **`resend/`**:
   - `resend_client.py`: Module phát hành email tự động qua Resend API.
   - `templates/`: Các mẫu HTML Email chuẩn responsive (Xác nhận đơn, Drip sequence).
5. **`telegram/`**:
   - `telegram_bot.py`: Bot Telegram gửi thông báo có nút bấm tương tác (Inline Keyboards) và nhận lệnh từ Admin.
   - `telegram_config.template.yaml`: Tệp cấu hình Token và Admin Chat IDs.

---

## ⚡ HƯỚNG DẪN KHỞI CHẠY TOÀN BỘ STACK TRONG 3 PHÚT

```bash
# 1. Di chuyển vào thư mục docker
cd infrastructure/docker

# 2. Tạo file cấu hình môi trường từ mẫu
cp .env.example .env
# Mở file .env và điền các API Key của bạn (Supabase, Resend, Telegram, VietQR)

# 3. Khởi chạy cụm Docker Compose
docker-compose up -d

# 4. Truy cập giao diện n8n:
# http://localhost:5678 (Tạo tài khoản admin và Import 5 workflows từ thư mục n8n-workflows/)
```
