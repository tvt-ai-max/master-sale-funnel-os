"""
====================================================================
CRON EMAIL DRIP RUNNER — SUPABASE + RESEND AUTOMATION
====================================================================
Executes scheduled email drip sequences from Supabase `email_sequences`
table using Resend Multi-tenant API. Matches toilatungplatform specs.
"""

import os
import sys
import json
from datetime import datetime, timedelta
from typing import Optional

try:
    from resend import Resend
except ImportError:
    Resend = None

from email_funnels import get_funnel_steps


def run_email_drip_cron(
    supabase_client=None,
    resend_api_key: Optional[str] = None,
    from_email: str = "Nguyễn Thanh Tùng <contact@toilatung.com>"
):
    """
    Scans Supabase `email_sequences` table for pending emails that are due,
    sends them via Resend, and enqueues the subsequent step.
    """
    resend_key = resend_api_key or os.getenv("RESEND_API_KEY")
    if not resend_key:
        print("[Email Drip Cron] ⚠️ RESEND_API_KEY not configured. Running in Dry-Run / Test mode.")
    
    # 1. Fetch pending emails from Supabase where scheduled_at <= now()
    now_iso = datetime.utcnow().isoformat() + "Z"
    
    print(f"[Email Drip Cron] 🕒 Starting cron run at: {now_iso}")
    
    if not supabase_client:
        print("[Email Drip Cron] ⚠️ Supabase client not provided. Simulating execution.")
        return {"ok": True, "processed": 0, "mocked": True}

    try:
        response = supabase_client.table("email_sequences") \
            .select("*") \
            .eq("status", "pending") \
            .lte("scheduled_at", now_iso) \
            .limit(50) \
            .execute()
        
        pending_items = response.data or []
        print(f"[Email Drip Cron] Found {len(pending_items)} due email(s).")
        
        sent_count = 0
        failed_count = 0

        for item in pending_items:
            seq_id = item.get("id")
            source = item.get("source", "master-funnel-v3-unpaid")
            current_step = item.get("step", 1)
            recipient_email = item.get("email")
            recipient_name = item.get("name") or "Bạn"

            steps = get_funnel_steps(source)
            step_config = next((s for s in steps if s["step"] == current_step), None)

            if not step_config:
                print(f"[Email Drip Cron] Step {current_step} does not exist for {source}. Marking completed.")
                supabase_client.table("email_sequences") \
                    .update({"status": "sent", "sent_at": datetime.utcnow().isoformat() + "Z"}) \
                    .eq("id", seq_id) \
                    .execute()
                continue

            # Render HTML
            html_content = step_config["render_html"](recipient_name, recipient_email)
            subject = step_config["subject"]

            # Send email via Resend
            send_success = False
            error_msg = None

            if resend_key:
                try:
                    import urllib.request
                    req_data = json.dumps({
                        "from": from_email,
                        "to": [recipient_email],
                        "subject": subject,
                        "html": html_content
                    }).encode("utf-8")

                    req = urllib.request.Request(
                        "https://api.resend.com/emails",
                        data=req_data,
                        headers={
                            "Authorization": f"Bearer {resend_key}",
                            "Content-Type": "application/json"
                        },
                        method="POST"
                    )
                    with urllib.request.urlopen(req) as resp:
                        if resp.status in [200, 201]:
                            send_success = True
                except Exception as e:
                    error_msg = str(e)
                    print(f"[Email Drip Cron] ❌ Error sending email to {recipient_email}: {error_msg}")
            else:
                # Dry run
                send_success = True
                print(f"[Email Drip Cron] [DRY RUN] Sent Step {current_step} ('{subject}') to {recipient_email}")

            if send_success:
                # Mark current step as sent
                supabase_client.table("email_sequences") \
                    .update({
                        "status": "sent",
                        "sent_at": datetime.utcnow().isoformat() + "Z"
                    }) \
                    .eq("id", seq_id) \
                    .execute()

                # Enqueue next step if available
                next_step_config = next((s for s in steps if s["step"] == current_step + 1), None)
                if next_step_config:
                    delay_diff = next_step_config["delay_days"] - step_config["delay_days"]
                    next_send_time = datetime.utcnow() + timedelta(days=delay_diff)
                    
                    supabase_client.table("email_sequences").insert({
                        "lead_id": item.get("lead_id"),
                        "source": source,
                        "email": recipient_email,
                        "name": recipient_name,
                        "step": next_step_config["step"],
                        "status": "pending",
                        "scheduled_at": next_send_time.isoformat() + "Z"
                    }).execute()
                    print(f"[Email Drip Cron] Enqueued Step {next_step_config['step']} for {recipient_email} at {next_send_time}")

                sent_count += 1
            else:
                supabase_client.table("email_sequences") \
                    .update({
                        "status": "failed",
                        "error": error_msg or "Unknown error"
                    }) \
                    .eq("id", seq_id) \
                    .execute()
                failed_count += 1

        print(f"[Email Drip Cron] Finished run. Sent: {sent_count}, Failed: {failed_count}")
        return {"ok": True, "sent": sent_count, "failed": failed_count}

    except Exception as err:
        print(f"[Email Drip Cron] ❌ Critical failure: {err}")
        return {"ok": False, "error": str(err)}


if __name__ == "__main__":
    run_email_drip_cron()
