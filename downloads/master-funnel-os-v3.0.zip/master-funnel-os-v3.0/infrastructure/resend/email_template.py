"""
====================================================================
EMAIL TEMPLATE GENERATOR — TOILATUNGPLATFORM DESIGN DNA
====================================================================
Standard HTML email generator with responsive layout, brand accents,
CTA buttons, quote boxes, and email-safe typography.
"""

def email_template(
    headline: str,
    body: str,
    preheader: str = "",
    tag: str = "TÔI LÀ TÙNG · AI NATIVE",
    footer_note: str = ""
) -> str:
    """
    Renders a responsive, clean, professional HTML email matching toilatung.com brand.
    """
    return f"""<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{headline}</title>
  <style>
    body {{ margin: 0; padding: 0; background-color: #0b0f19; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #cbd5e1; -webkit-font-smoothing: antialiased; }}
    table {{ border-collapse: collapse; }}
    .container {{ max-width: 600px; margin: 0 auto; background-color: #0f172a; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }}
    .header {{ padding: 32px 32px 20px 32px; border-bottom: 1px solid #1e293b; background-color: #0f172a; }}
    .tag {{ display: inline-block; font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.15em; color: #f2552c; background-color: rgba(242, 85, 44, 0.1); border: 1px solid rgba(242, 85, 44, 0.25); padding: 4px 10px; border-radius: 999px; margin-bottom: 12px; }}
    .headline {{ font-size: 22px; font-weight: 800; color: #ffffff; line-height: 1.35; margin: 0; }}
    .content {{ padding: 32px; font-size: 15px; line-height: 1.68; color: #94a3b8; }}
    .content p {{ margin: 0 0 16px 0; color: #cbd5e1; }}
    .content strong {{ color: #ffffff; }}
    .cta-btn {{ display: inline-block; background-color: #f2552c; color: #ffffff !important; font-size: 14px; font-weight: 700; text-decoration: none; padding: 14px 28px; border-radius: 10px; margin: 20px 0; text-align: center; box-shadow: 0 4px 14px rgba(242, 85, 44, 0.3); }}
    .divider {{ height: 1px; background-color: #1e293b; margin: 24px 0; }}
    .callout {{ background-color: #1e293b; border-left: 4px solid #f2552c; border-radius: 8px; padding: 16px 20px; margin: 20px 0; }}
    .callout p {{ margin: 0; color: #e2e8f0; font-size: 14px; }}
    .signature {{ margin-top: 28px; padding-top: 20px; border-top: 1px solid #1e293b; font-size: 13px; color: #64748b; }}
    .signature strong {{ color: #e2e8f0; display: block; margin-bottom: 2px; }}
    .footer {{ padding: 24px 32px; background-color: #0b0f19; text-align: center; font-size: 12px; color: #475569; }}
    .footer a {{ color: #64748b; text-decoration: underline; }}
  </style>
</head>
<body>
  <div style="display:none;font-size:1px;color:#0b0f19;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;">
    {preheader}
  </div>

  <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color:#0b0f19; padding: 32px 16px;">
    <tr>
      <td align="center">
        <div class="container">
          <!-- Header -->
          <div class="header">
            <div class="tag">{tag}</div>
            <h1 class="headline">{headline}</h1>
          </div>

          <!-- Body -->
          <div class="content">
            {body}
          </div>

          <!-- Footer -->
          <div class="footer">
            <p style="margin: 0 0 8px 0;"><strong>toilatung.com</strong> · Kiến trúc hệ thống AI-Native & Tự động hóa vận hành</p>
            <p style="margin: 0 0 8px 0;">Nguyễn Thanh Tùng · Founder & AI System Architect · Hotline/Zalo: 0972 613 555 · contact@toilatung.com</p>
            {f'<p style="margin: 8px 0 0 0; color: #64748b; font-style: italic;">{footer_note}</p>' if footer_note else ''}
            <p style="margin: 12px 0 0 0;"><a href="https://toilatung.com">Trang chủ</a> · <a href="https://salefunnel.toilatung.com">Sale Funnel OS</a> · <a href="https://lexioperator.com/nhan-su-ai">16 Nhân Sự AI</a></p>
          </div>
        </div>
      </td>
    </tr>
  </table>
</body>
</html>"""


def cta_button(text: str, url: str) -> str:
    return f"""<div style="text-align: center; margin: 24px 0;">
  <a href="{url}" class="cta-btn" target="_blank">{text}</a>
</div>"""


def callout_box(text: str, title: str = "") -> str:
    title_html = f"<div style='color:#f2552c;font-weight:bold;margin-bottom:6px;font-size:13px;text-transform:uppercase;'>{title}</div>" if title else ""
    return f"""<div class="callout">
  {title_html}
  <p>{text}</p>
</div>"""


def bullet_list(items: list[str]) -> str:
    lis = "".join([f"<li style='margin-bottom: 8px; color: #cbd5e1;'>{item}</li>" for item in items])
    return f"<ul style='padding-left: 20px; margin: 16px 0;'>{lis}</ul>"


def signature() -> str:
    return """<div class="signature">
  <strong>Nguyễn Thanh Tùng</strong>
  <span>Founder & AI System Architect · <a href="https://toilatung.com" style="color:#f2552c;text-decoration:none;">toilatung.com</a></span>
</div>"""
