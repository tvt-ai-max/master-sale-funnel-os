import os
import requests
import json

class ResendEmailClient:
    def __init__(self, api_key=None, from_email=None, from_name=None):
        self.api_key = api_key or os.getenv("RESEND_API_KEY", "")
        self.from_email = from_email or os.getenv("RESEND_FROM_EMAIL", "onboarding@resend.dev")
        self.from_name = from_name or os.getenv("RESEND_FROM_NAME", "Customer Success Team")
        self.api_url = "https://api.resend.com/emails"

    def send_email(self, to_email, subject, html_content):
        if not self.api_key:
            print(f"⚠️ Resend API Key is missing. Mock sent to {to_email}: {subject}")
            return {"id": "mock-resend-id", "status": "simulated"}

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "from": f"{self.from_name} <{self.from_email}>",
            "to": [to_email],
            "subject": subject,
            "html": html_content
        }
        res = requests.post(self.api_url, headers=headers, json=payload, timeout=10)
        if res.status_code in [200, 201]:
            return res.json()
        else:
            return {"error": res.text, "status_code": res.status_code}

    def render_template(self, template_name, context):
        tmpl_path = os.path.join(os.path.dirname(__file__), "templates", template_name)
        if not os.path.exists(tmpl_path):
            return f"<h1>Chào {context.get('customer_name', '')}</h1><p>Đơn hàng của bạn đã hoàn tất.</p>"
        with open(tmpl_path, "r", encoding="utf-8") as f:
            content = f.read()
        for k, v in context.items():
            content = content.replace(f"{{{{{k}}}}}", str(v))
        return content
