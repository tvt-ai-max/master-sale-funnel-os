"""
====================================================================
DUAL EMAIL FUNNELS ENGINE — TOILATUNGPLATFORM SPECIFICATION
====================================================================
Defines the two interconnected email sequences:
1. UNPAID FUNNEL (master-funnel-v3-unpaid):
   - Nurtures, educates, handles objections, triggers conversion.
2. PAID FUNNEL (master-funnel-v3-paid):
   - Delivers digital assets (60 files), onboards, shares audit gates, upsells AI Workforce.
"""

from typing import Callable, TypedDict, List
try:
    from .email_template import email_template, cta_button, callout_box, bullet_list, signature
except ImportError:
    from email_template import email_template, cta_button, callout_box, bullet_list, signature


class FunnelStep(TypedDict):
    step: int
    delay_days: int
    subject: str
    render_html: Callable[[str, str], str]


# --------------------------------------------------------------------
# 1. UNPAID / ABANDONED CHECKOUT FUNNEL (4 STEPS)
# --------------------------------------------------------------------
UNPAID_FUNNEL: List[FunnelStep] = [
    {
        "step": 1,
        "delay_days": 0,  # Tức thì khi nhập form
        "subject": "⏳ [Giữ Chỗ 386k] Hướng dẫn nhận Bộ Khung Master Sale Funnel OS v3.0",
        "render_html": lambda name, email: email_template(
            headline=f"Chào {name}, mã VietQR giữ chỗ của bạn đã sẵn sàng 👇",
            preheader="Mã thanh toán SePay 386.000đ và quà tặng Checklist Audit đính kèm bên trong.",
            tag="XÁC NHẬN GIỮ CHỖ · SEPAY VIETQR",
            body=f"""
            <p>Cảm ơn bạn đã đăng ký sở hữu <strong>Bộ Khung Enterprise Master Sale Funnel & Automation OS v3.0</strong>.</p>
            <p>Hệ thống ghi nhận đơn hàng của bạn đang ở trạng thái <em>Chờ chuyển khoản</em>. Để nhận link tải toàn bộ 60 tệp mã nguồn và động cơ Hermes AI Agent, bạn chỉ cần quét mã VietQR bên dưới:</p>
            
            {callout_box(f'''
            <strong>THÔNG TIN THANH TOÁN TỰ ĐỘNG SEPAY:</strong><br/>
            • Ngân hàng: <strong>MB Bank (Quân Đội)</strong><br/>
            • Số tài khoản: <strong>0912210457</strong><br/>
            • Chủ tài khoản: <strong>NGUYEN THANH TUNG</strong><br/>
            • Số tiền: <strong>386.000 VNĐ</strong><br/>
            • Nội dung CK: <strong>TVT {name}</strong> (Hoặc quét QR trên màn hình)
            ''', title="CỔNG THANH TOÁN TỰ ĐỘNG NAPAS247")}

            <p>🎁 <strong>Quà tặng đính kèm:</strong> Bạn có thể đọc trước bản tóm tắt <em>10 Sub-Skills Xây Phễu Chuyển Đổi Cao</em> trong lúc chờ kích hoạt.</p>
            {cta_button("Mở Lại Trang Thanh Toán VietQR →", "https://salefunnel.toilatung.com#offer")}
            
            <p>Ngay khi bạn chuyển khoản thành công, hệ thống SePay sẽ tự động gửi email chứa link tải mã nguồn vào hộp thư này sau 10 giây.</p>
            {signature()}
            """
        )
    },
    {
        "step": 2,
        "delay_days": 1,  # Sau 24h
        "subject": "Director Mindset: Tại sao 95% phễu bán hàng hiện nay bị dính 'AI Slop'?",
        "render_html": lambda name, email: email_template(
            headline=f"{name} — Bạn đang dùng AI như công cụ chat hay hệ thống vận hành?",
            preheader="Đừng để các đoạn code và content AI sáo rỗng phá hỏng tỷ lệ chuyển đổi của bạn.",
            tag="DIRECTOR MINDSET · CHIA SẺ THỰC CHIẾN",
            body=f"""
            <p>Chào {name},</p>
            <p>Hầu hết mọi người khi dùng AI để viết Sale Page hoặc làm Marketing đều mắc phải một sai lầm chết người: <strong>Mở ChatGPT lên và gõ prompt ngẫu hứng</strong>.</p>
            <p>Kết quả là gì? Văn phong máy móc, gạch đầu dòng tràn lan, emoji lộn xộn — thứ mà giới công nghệ gọi là <strong style='color:#f2552c;'>AI Slop</strong>. Khách hàng đọc vào sẽ nhận ra ngay và rời đi trong 3 giây.</p>
            <p>Đó là lý do tôi đóng gói <strong>Kiến Trúc 3 Lớp Vận Hành (Harness - Graph - Loop)</strong> trong Bộ Khung Master Funnel:</p>
            {bullet_list([
                "<strong>Harness Engineering:</strong> Nạp Brand DNA và SQLite Memory để AI hiểu sâu sản phẩm trước khi viết.",
                "<strong>Graph Engineering:</strong> Phân rã luồng công việc thành Đồ thị DAG nhiều Agent phối hợp.",
                "<strong>Loop Engineering:</strong> Chạy 30-Point Audit Gate tự động gọt giũa 3 vòng lặp trước khi xuất bản."
            ])}
            <p>Chỉ với <strong>386.000đ</strong>, bạn sở hữu toàn bộ bí quyết và 60 tệp mã nguồn chuẩn studio này.</p>
            {cta_button("Sở Hữu Bộ Khung Mã Nguồn Ngay →", "https://salefunnel.toilatung.com#offer")}
            {signature()}
            """
        )
    },
    {
        "step": 3,
        "delay_days": 3,  # Sau 3 ngày
        "subject": "Case Study: Triển khai phễu bán hàng đa ngành trong 3 giờ thay vì 3 tuần",
        "render_html": lambda name, email: email_template(
            headline=f"Cách nhân bản phễu cho 6 ngành nghề khác nhau, {name}",
            preheader="Bóc tách cấu trúc 6 Presets (SaaS, Spa, BĐS, Agency) kèm Hermes AI Agent.",
            tag="THỰC HÀNH TRIỂN KHAI · PRESETS MATRIX",
            body=f"""
            <p>Chào {name},</p>
            <p>Một trong những điểm đột phá nhất của Bộ Khung v3.0 là <strong>6 Presets Ngành Nghề May Đo Sẵn</strong>:</p>
            {bullet_list([
                "<strong>B2B SaaS / Tech:</strong> Tối ưu Free Trial, TCO Calculator và API Demo.",
                "<strong>Thẩm Mỹ / Clinic:</strong> Phễu tư vấn soi da, đặt cọc dịch vụ, đánh giá an toàn Y khoa.",
                "<strong>Khóa Học / Coaching:</strong> Phễu Micro-Offer 386k, Value Ladder và Video Training.",
                "<strong>Bất Động Sản:</strong> Form thẩm định quy hoạch, tải bảng tính ROI đầu tư.",
                "<strong>E-commerce High-Ticket:</strong> Combo quà tặng Grand Slam, Flash Sale có đồng hồ đếm ngược.",
                "<strong>B2B Agency:</strong> Khảo sát điểm nghẽn quy trình, đặt lịch Audit chiến lược 1-1."
            ])}
            <p>Bạn chỉ cần sửa 1 tệp cấu hình <code>client-project-config.template.yaml</code>, Hermes AI Agent sẽ tự động sinh ra toàn bộ mã nguồn phễu tương ứng.</p>
            {cta_button("Nhận Toàn Bộ 6 Presets Ngay (386k) →", "https://salefunnel.toilatung.com#offer")}
            {signature()}
            """
        )
    },
    {
        "step": 4,
        "delay_days": 5,  # Sau 5 ngày
        "subject": "⚠️ Cơ hội cuối: Suất chuyển nhượng 386.000đ sắp đóng lại",
        "render_html": lambda name, email: email_template(
            headline=f"{name}, đây là cơ hội cuối cùng để nhận giá ưu đãi 386k",
            preheader="Cam kết chất lượng thực chiến 100% và bản quyền sử dụng không giới hạn dự án.",
            tag="CẢNH BÁO ƯU ĐÃI · CƠ HỘI CUỐI",
            body=f"""
            <p>Chào {name},</p>
            <p>Mức giá <strong>386.000đ</strong> là chương trình hỗ trợ cộng đồng giới hạn cho 100 suất đầu tiên. Sau khi đủ số lượng, gói sẽ trở về giá niêm yết <strong>1.500.000đ</strong>.</p>
            <p><strong>Cam kết chất lượng & giá trị thực chiến:</strong> Toàn bộ 60 tệp mã nguồn, 10 Sub-Skills, 6 Presets ngành và động cơ Hermes AI Agent đều là tài sản đã được kiểm thử, chạy thực tế tại TVT Agency. Bạn có toàn quyền sử dụng vĩnh viễn cho không giới hạn số lượng dự án khách hàng.</p>
            {cta_button("Kích Hoạt Tải Về Trọn Gói 386k →", "https://salefunnel.toilatung.com#offer")}
            {signature()}
            """
        )
    }
]


# --------------------------------------------------------------------
# 2. PAID / ONBOARDING & UPSELL FUNNEL (4 STEPS)
# --------------------------------------------------------------------
PAID_FUNNEL: List[FunnelStep] = [
    {
        "step": 1,
        "delay_days": 0,  # Tức thì sau khi thanh toán SePay thành công
        "subject": "🎉 [TẢI VỀ NGAY] Trọn bộ 60 Tệp Mã Nguồn Enterprise Master Funnel & Hermes Agent v3.0",
        "render_html": lambda name, email: email_template(
            headline=f"Chúc mừng {name}! Giao dịch của bạn đã kích hoạt thành công 🚀",
            preheader="Link tải Google Drive, GitHub Private Repo và video hướng dẫn 1-Click của bạn.",
            tag="GIAO HÀNG TỰ ĐỘNG · BẢN QUYỀN VĨNH VIỄN",
            body=f"""
            <p>Cảm ơn bạn đã tin tưởng và đồng hành cùng <strong>toilatung.com</strong>.</p>
            <p>Hệ thống SePay đã ghi nhận thanh toán thành công của bạn. Dưới đây là link truy cập toàn bộ tài sản kỹ thuật:</p>
            
            {callout_box('''
            <strong>KHO TÀI NGUYÊN BÀN GIAO:</strong><br/>
            • <strong>Google Drive Master:</strong> <a href="https://drive.google.com/drive/folders/toilatung-funnel-os-v3" style="color:#f2552c;font-weight:bold;">Tải Gói Nén ZIP Đầy Đủ (60 Files)</a><br/>
            • <strong>GitHub Repository:</strong> <a href="https://github.com/tvtagency/skill-sale-funnel" style="color:#f2552c;">Truy cập mã nguồn Git</a><br/>
            • <strong>Video Hướng Dẫn:</strong> <a href="https://toilatung.com/skills" style="color:#f2552c;">Xem video cài đặt từng bước</a>
            ''', title="LIÊN KẾT TRUY CẬP ĐỘC QUYỀN")}

            {cta_button("Tải Toàn Bộ Kho Mã Nguồn (Drive) →", "https://drive.google.com/drive/folders/toilatung-funnel-os-v3")}
            
            <p><strong>Hướng dẫn khởi động nhanh trong 3 phút:</strong></p>
            {bullet_list([
                "1. Giải nén thư mục và mở terminal tại <code>hermes-agent/</code>.",
                "2. Chạy lệnh <code>bash install.sh</code> (trên Mac/Linux) hoặc <code>install.bat</code> (trên Windows).",
                "3. Chạy <code>python run_agent.py</code> để bắt đầu tương tác với Hermes AI Agent."
            ])}
            <p>Nếu bạn gặp bất kỳ vướng mắc kỹ thuật nào, hãy reply trực tiếp email này hoặc nhắn qua Zalo <strong>0972 613 555</strong>.</p>
            {signature()}
            """
        )
    },
    {
        "step": 2,
        "delay_days": 1,  # Sau 24h
        "subject": "Lộ trình 3 bước khởi động cỗ máy Sale Funnel đầu tiên trong 3 giờ",
        "render_html": lambda name, email: email_template(
            headline=f"{name}, bạn đã chạy thử Hermes AI Agent chưa?",
            preheader="Bí quyết cấu hình nhanh file YAML để tạo Sale Page đầu tiên.",
            tag="ONBOARDING THỰC CHIẾN · BƯỚC 1",
            body=f"""
            <p>Chào {name},</p>
            <p>Để không bị choáng ngợp bởi 60 tệp mã nguồn, đây là <strong>3 bước tinh gọn nhất</strong> bạn nên làm ngay hôm nay:</p>
            {bullet_list([
                "<strong>Bước 1:</strong> Mở tệp <code>configs/client-project-config.template.yaml</code> và điền tên sản phẩm, giá bán, đối tượng khách hàng mục tiêu.",
                "<strong>Bước 2:</strong> Chạy lệnh <code>/project configs/client-project-config.template.yaml</code> trong Hermes CLI để nạp ngữ cảnh.",
                "<strong>Bước 3:</strong> Gõ lệnh <code>/skill 03-copywriting-engine</code> để AI tự động xuất bản 10 Sections Copywriting không tì vết."
            ])}
            <p>Chỉ cần làm đúng 3 bước này, bạn sẽ có toàn bộ nội dung phễu hoàn chỉnh sau chưa đầy 30 phút.</p>
            {cta_button("Xem Tài Liệu Hướng Dẫn Chi Tiết →", "https://salefunnel.toilatung.com#hermes")}
            {signature()}
            """
        )
    },
    {
        "step": 3,
        "delay_days": 3,  # Sau 3 ngày
        "subject": "Checklist 30-Point Audit Gate: Bí quyết kiểm thử chất lượng trước khi ra mắt",
        "render_html": lambda name, email: email_template(
            headline=f"Vượt qua 30 Điểm Kiểm Toán Chất Lượng, {name}",
            preheader="Công cụ tự động rà soát chống gãy link, chống AI Slop và tối ưu chuyển đổi.",
            tag="QUALITY ASSURANCE · 30-POINT AUDIT",
            body=f"""
            <p>Chào {name},</p>
            <p>Trước khi đổ tiền chạy quảng cáo hoặc gửi phễu cho khách hàng, việc kiểm thử là tối quan trọng.</p>
            <p>Trong thư mục <code>audit-gate/30-POINT-AUDIT-CHECKLIST.md</code> (kèm script tự động <code>audit-gate/30-point-audit-validator.py</code>), tôi đã đính kèm bảng kiểm 30 tiêu chí nghiêm ngặt bao gồm:</p>
            {bullet_list([
                "<strong>Mobile Responsive & Core Web Vitals:</strong> LCP < 1.2s, không tràn khung ngang trên iPhone/Android.",
                "<strong>VietQR & SePay Payload Check:</strong> Quét thử mã QR thực tế, kiểm tra độ chính xác của nội dung CK.",
                "<strong>Anti-AI Slop Grammar Gate:</strong> Không chứa câu từ sáo rỗng, loại bỏ 100% placeholder TODO.",
                "<strong>CAPI Event Deduplication:</strong> Kiểm tra mã <code>event_id</code> tránh đếm trùng chuyển đổi."
            ])}
            <p>Chúc bạn ra mắt những chiến dịch phễu bùng nổ doanh số!</p>
            {signature()}
            """
        )
    },
    {
        "step": 4,
        "delay_days": 7,  # Sau 7 ngày
        "subject": "Đòn bẩy tiếp theo: Bạn đã sẵn sàng thuê 16 Nhân Sự AI vận hành phễu 24/7?",
        "render_html": lambda name, email: email_template(
            headline=f"{name} — Đã đến lúc tự động hóa hoàn toàn đội ngũ vận hành phễu",
            preheader="Thuê lẻ từng Agent hoặc trọn bộ phòng ban AI chuyên khoa tại Lexi Operator.",
            tag="UPSELL & SCALE · LỰC LƯỢNG 16 AI AGENTS",
            body=f"""
            <p>Chào {name},</p>
            <p>Sau 1 tuần làm quen với bộ khung, bạn đã thấy sức mạnh của việc chuẩn hóa quy trình bằng AI.</p>
            <p>Nhưng nếu bạn muốn <strong>hoàn toàn giải phóng bản thân</strong> khỏi việc viết bài mỗi ngày, trực lead VietQR, thiết kế banner và theo dõi số liệu quảng cáo — hãy khám phá <strong>Dịch Vụ Cho Thuê 16 Nhân Sự AI Enterprise</strong> tại Lexi Operator:</p>
            {bullet_list([
                "<strong>Ally (Support & Lead CRM):</strong> Trực tiếp đối soát VietQR và chăm sóc khách 24/7.",
                "<strong>Quill & North:</strong> Tự động nghiên cứu từ khóa và viết bài SEO/GEO hàng tuần.",
                "<strong>Craft & Pixel:</strong> Thiết kế toàn bộ visual assets, banner và thumbnail chuẩn Open Design.",
                "<strong>Bolt (Automation Engineer):</strong> Vận hành hệ thống n8n, webhook và xử lý sự cố."
            ])}
            <p>Mức phí thuê chỉ từ <strong>1.800.000đ / tháng / Agent</strong> hoặc <strong>6.500.000đ / tháng / Bộ phòng ban</strong> (đã bao gồm hạ tầng VPS Cloud và nạp sẵn tri thức RAG riêng biệt).</p>
            {cta_button("Khám Phá 16 Nhân Sự AI Enterprise →", "https://lexioperator.com/nhan-su-ai")}
            
            <p style='margin-top: 20px;'>Ngoài ra, nếu doanh nghiệp của bạn cần <strong>Tư vấn May Đo Kiến Trúc 1-1</strong>, tôi vẫn dành riêng 4 suất mỗi tháng:</p>
            {cta_button("Đăng Ký Buổi Tư Vấn Chiến Lược 1-1 →", "https://toilatung.com/lien-he")}
            {signature()}
            """
        )
    }
]


def get_funnel_steps(source: str) -> List[FunnelStep]:
    """Returns the list of steps for a given funnel source name."""
    if "unpaid" in source.lower():
        return UNPAID_FUNNEL
    elif "paid" in source.lower():
        return PAID_FUNNEL
    return UNPAID_FUNNEL
