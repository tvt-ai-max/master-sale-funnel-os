import os
import requests
import json

class TelegramFunnelNotifier:
    def __init__(self, token=None, default_chat_id=None):
        self.token = token or os.getenv("TELEGRAM_BOT_TOKEN", "")
        self.default_chat_id = default_chat_id or os.getenv("TELEGRAM_ADMIN_CHAT_ID", "")
        self.base_url = f"https://api.telegram.org/bot{self.token}"

    def send_notification(self, text, chat_id=None, reply_markup=None):
        target_chat = chat_id or self.default_chat_id
        if not self.token or not target_chat:
            print(f"⚠️ Telegram Token/ChatID missing. Mock Alert:\n{text}")
            return {"ok": False, "reason": "Credentials missing"}

        url = f"{self.base_url}/sendMessage"
        payload = {
            "chat_id": target_chat,
            "text": text,
            "parse_mode": "HTML"
        }
        if reply_markup:
            payload["reply_markup"] = json.dumps(reply_markup)

        res = requests.post(url, json=payload, timeout=10)
        return res.json()

    def alert_new_order(self, order_code, name, phone, email, amount, product):
        msg = f"""
<b>🔔 ĐƠN HÀNG MỚI ĐÃ THANH TOÁN THÀNH CÔNG!</b>
━━━━━━━━━━━━━━━━━━
• <b>Mã đơn:</b> <code>#{order_code}</code>
• <b>Khách hàng:</b> {name}
• <b>Số điện thoại:</b> <code>{phone}</code>
• <b>Email:</b> {email}
• <b>Gói sản phẩm:</b> {product}
• <b>Thực thu:</b> <b>{amount:,.0f} VNĐ</b>
━━━━━━━━━━━━━━━━━━
<i>Hệ thống đã tự động gửi email kích hoạt và nạp vào CRM.</i>
"""
        keyboard = {
            "inline_keyboard": [
                [
                    {"text": "💬 Nhắn Zalo", "url": f"https://zalo.me/{phone}"},
                    {"text": "📞 Gọi Điện Thoại", "url": f"tel:{phone}"}
                ]
            ]
        }
        return self.send_notification(msg, reply_markup=keyboard)

    def alert_new_lead(self, name, phone, email, industry):
        msg = f"""
<b>🎯 LEAD MỚI ĐIỀN FORM!</b>
━━━━━━━━━━━━━━━━━━
• <b>Khách hàng:</b> {name}
• <b>Số điện thoại:</b> <code>{phone}</code>
• <b>Email:</b> {email or 'Chưa cung cấp'}
• <b>Mã ngành:</b> {industry}
━━━━━━━━━━━━━━━━━━
<i>Sales hãy liên hệ hỗ trợ trong vòng 15 phút!</i>
"""
        return self.send_notification(msg)
