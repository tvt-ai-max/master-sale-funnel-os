-- ==========================================================
-- SUPABASE / POSTGRESQL SCHEMA FOR SALE FUNNEL & SEPAY AUTOMATION
-- Matches toilatungplatform production standards (toilatung.com/skills)
-- ==========================================================

-- 1. BẢNG LEADS (KHÁCH HÀNG & TIẾN TRÌNH THANH TOÁN JSONB)
CREATE TABLE IF NOT EXISTS leads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    source TEXT DEFAULT 'master-funnel-v3',
    website_id TEXT DEFAULT 'toilatung.com',
    form_id TEXT DEFAULT 'checkout-modal',
    created_via TEXT DEFAULT 'checkout',
    fields JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. BẢNG HÓA ĐƠN & ĐỐI SOÁT TỰ ĐỘNG SEPAY (INVOICES)
CREATE TABLE IF NOT EXISTS invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lead_id UUID REFERENCES leads(id) ON DELETE SET NULL,
    website_id TEXT DEFAULT 'toilatung.com',
    invoice_code TEXT UNIQUE NOT NULL,
    product_id TEXT NOT NULL,
    description TEXT,
    amount NUMERIC(15, 2) NOT NULL,
    currency TEXT DEFAULT 'VND',
    status TEXT DEFAULT 'pending', -- [pending, paid, cancelled, refunded]
    payment_method TEXT DEFAULT 'sepay',
    transfer_content TEXT,
    sepay_transaction_id TEXT,
    created_via TEXT DEFAULT 'checkout',
    paid_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. BẢNG TIẾN TRÌNH CHUỖI EMAIL DRIP (EMAIL SEQUENCES)
CREATE TABLE IF NOT EXISTS email_sequences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
    source TEXT NOT NULL, -- [master-funnel-v3-unpaid, master-funnel-v3-paid]
    email TEXT NOT NULL,
    name TEXT NOT NULL,
    step INTEGER NOT NULL DEFAULT 1,
    status TEXT DEFAULT 'pending', -- [pending, sent, failed]
    scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL,
    sent_at TIMESTAMP WITH TIME ZONE,
    error TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. BẢNG LƯU TRỮ HỘI THOẠI CHATBOT & AUDIT LOGS
CREATE TABLE IF NOT EXISTS chat_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    channel TEXT NOT NULL, -- [TELEGRAM, FACEBOOK, ZALO, WEB]
    sender_id TEXT NOT NULL,
    sender_name TEXT,
    message_text TEXT NOT NULL,
    bot_reply TEXT,
    intent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- INDEXES TỐI ƯU HIỆU NĂNG TRUY VẤN
CREATE INDEX IF NOT EXISTS idx_leads_phone ON leads(phone);
CREATE INDEX IF NOT EXISTS idx_leads_email ON leads(email);
CREATE INDEX IF NOT EXISTS idx_leads_fields ON leads USING gin (fields);
CREATE INDEX IF NOT EXISTS idx_invoices_code ON invoices(invoice_code);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoices_lead ON invoices(lead_id);
CREATE INDEX IF NOT EXISTS idx_email_seq_status_sched ON email_sequences(status, scheduled_at);
CREATE INDEX IF NOT EXISTS idx_email_seq_lead_source ON email_sequences(lead_id, source);

-- RLS (ROW LEVEL SECURITY) POLICIES
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_sequences ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_conversations ENABLE ROW LEVEL SECURITY;

-- Anonymous public inserts for lead forms / checkouts
CREATE POLICY "Allow public insert on leads" ON leads FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public insert on invoices" ON invoices FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow service role full access" ON leads FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Allow service role full access invoices" ON invoices FOR ALL USING (auth.role() = 'service_role');
CREATE POLICY "Allow service role full access email_sequences" ON email_sequences FOR ALL USING (auth.role() = 'service_role');
