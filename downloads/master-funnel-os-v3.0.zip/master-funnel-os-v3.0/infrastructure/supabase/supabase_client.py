import os
import requests
import json
from datetime import datetime

class SupabaseFunnelClient:
    def __init__(self, url=None, key=None):
        self.url = url or os.getenv("SUPABASE_URL", "")
        self.key = key or os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")
        self.headers = {
            "apikey": self.key,
            "Authorization": f"Bearer {self.key}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }

    def insert_lead(self, full_name, phone, email=None, industry="IND-01", source="landing_page", utm=None):
        if not self.url or not self.key:
            print("⚠️ Supabase credentials not found. Running in mock mode.")
            return {"id": "mock-lead-id", "full_name": full_name, "phone": phone}

        endpoint = f"{self.url}/rest/v1/crm_leads"
        payload = {
            "full_name": full_name,
            "phone": phone,
            "email": email,
            "industry_code": industry,
            "source_funnel": source,
            "utm_source": (utm or {}).get("utm_source"),
            "utm_campaign": (utm or {}).get("utm_campaign")
        }
        res = requests.post(endpoint, headers=self.headers, json=payload, timeout=10)
        return res.json() if res.status_code in [200, 201] else {"error": res.text}

    def create_order(self, order_code, name, phone, email, product, amount):
        if not self.url or not self.key:
            return {"id": "mock-order-id", "order_code": order_code, "status": "PENDING"}

        endpoint = f"{self.url}/rest/v1/funnel_orders"
        payload = {
            "order_code": order_code,
            "customer_name": name,
            "customer_phone": phone,
            "customer_email": email,
            "product_name": product,
            "amount": amount,
            "payment_status": "PENDING"
        }
        res = requests.post(endpoint, headers=self.headers, json=payload, timeout=10)
        return res.json() if res.status_code in [200, 201] else {"error": res.text}

    def mark_order_paid(self, order_code, transaction_ref=None):
        if not self.url or not self.key:
            return {"order_code": order_code, "status": "PAID"}

        endpoint = f"{self.url}/rest/v1/funnel_orders?order_code=eq.{order_code}"
        payload = {
            "payment_status": "PAID",
            "transaction_ref": transaction_ref,
            "paid_at": datetime.utcnow().isoformat()
        }
        res = requests.patch(endpoint, headers=self.headers, json=payload, timeout=10)
        return res.json() if res.status_code in [200, 204] else {"error": res.text}
