import os
import requests
import json
from datetime import datetime

class SupabaseFunnelClient:
    def __init__(self, url=None, key=None):
        self.url = url or os.getenv("SUPABASE_URL", "")
        self.key = key or os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")
        self.headers = {
            "apikey": self.key,
            "Authorization": f"Bearer {self.key}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }

    def insert_lead(self, full_name, phone, email=None, industry="IND-01", source="landing_page", utm=None):
        """Ghi vào bảng `leads` — đúng tên bảng trong infrastructure/supabase/schema.sql."""
        if not self.url or not self.key:
            print("⚠️ Supabase credentials not found. Running in mock mode.")
            return {"id": "mock-lead-id", "name": full_name, "phone": phone}

        endpoint = f"{self.url}/rest/v1/leads"
        payload = {
            "name": full_name,
            "phone": phone,
            "email": email,
            "source": source,
            "fields": {
                "industry_code": industry,
                "utm_source": (utm or {}).get("utm_source"),
                "utm_campaign": (utm or {}).get("utm_campaign")
            }
        }
        res = requests.post(endpoint, headers=self.headers, json=payload, timeout=10)
        return res.json() if res.status_code in [200, 201] else {"error": res.text}

    def find_lead_by_phone(self, phone):
        """Tra bảng `leads` theo SĐT, lấy lead mới nhất — dùng khi webhook SePay nhận tiền."""
        if not self.url or not self.key:
            return None

        endpoint = f"{self.url}/rest/v1/leads"
        params = {"phone": f"eq.{phone}", "order": "updated_at.desc", "limit": 1}
        res = requests.get(endpoint, headers=self.headers, params=params, timeout=10)
        if res.status_code == 200 and res.json():
            return res.json()[0]
        return None

    def create_order(self, order_code, lead_id, product, amount):
        """Ghi vào bảng `invoices` — đúng tên bảng trong schema.sql (không phải funnel_orders)."""
        if not self.url or not self.key:
            return {"id": "mock-invoice-id", "invoice_code": order_code, "status": "pending"}

        endpoint = f"{self.url}/rest/v1/invoices"
        payload = {
            "lead_id": lead_id,
            "invoice_code": order_code,
            "product_id": product,
            "amount": amount,
            "status": "pending",
            "payment_method": "sepay",
            "transfer_content": order_code
        }
        res = requests.post(endpoint, headers=self.headers, json=payload, timeout=10)
        return res.json() if res.status_code in [200, 201] else {"error": res.text}

    def mark_order_paid(self, order_code, transaction_ref=None):
        if not self.url or not self.key:
            return {"invoice_code": order_code, "status": "paid"}

        endpoint = f"{self.url}/rest/v1/invoices?invoice_code=eq.{order_code}"
        payload = {
            "status": "paid",
            "sepay_transaction_id": transaction_ref,
            "paid_at": datetime.utcnow().isoformat()
        }
        res = requests.patch(endpoint, headers=self.headers, json=payload, timeout=10)
        return res.json() if res.status_code in [200, 204] else {"error": res.text}
