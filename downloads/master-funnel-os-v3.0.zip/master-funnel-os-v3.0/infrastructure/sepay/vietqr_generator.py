#!/usr/bin/env python3
"""
⚡ VIETQR & SEPAY GENERATOR 1-CLICK (VŨ KHÍ 3)
Hỗ trợ tạo link ảnh VietQR động và chuỗi chuyển khoản chuẩn SePay MB Bank.
"""
import urllib.parse

def generate_vietqr_url(bank_id: str, account_no: str, amount: int, transfer_content: str, template: str = "compact") -> str:
    encoded_des = urllib.parse.quote(transfer_content)
    return f"https://qr.sepay.vn/img?bank={bank_id}&acc={account_no}&template={template}&amount={amount}&des={encoded_des}"

if __name__ == "__main__":
    print("==================================================")
    print("💳 SEPAY VIETQR GENERATOR 1-CLICK")
    print("==================================================")
    bank = "mbbank"
    acc = "0912210457"
    amount = 386000
    phone = "0972613555"
    content = f"TVT {phone}"
    
    qr_url = generate_vietqr_url(bank, acc, amount, content)
    print(f"Ngân hàng: {bank.upper()} | STK: {acc}")
    print(f"Số tiền: {amount:,} VNĐ | Cú pháp: {content}")
    print(f"👉 Link ảnh QR Code:")
    print(qr_url)
    print("==================================================")
