#!/usr/bin/env python3
"""
⚡ SEPAY WEBHOOK RECEIVER & AUTO-DELIVERY (FASTAPI)
Nhận webhook đối soát giao dịch từ SePay và tự động kích hoạt gửi tài liệu.
"""
from fastapi import FastAPI, Request, HTTPException, Header
import os
import re

app = FastAPI(title="SePay Auto-Delivery Webhook Gateway")

API_KEY = os.environ["SEPAY_WEBHOOK_TOKEN"]  # bắt buộc set qua biến môi trường, không hard-code

@app.post("/api/sepay/webhook")
async def sepay_webhook(request: Request, authorization: str = Header(None)):
    if authorization != f"Bearer {API_KEY}":
        raise HTTPException(status_code=401, detail="invalid webhook token")

    payload = await request.json()
    print(f"📩 Nhận giao dịch từ SePay: {payload.get('gateway')} - {payload.get('transferAmount'):,}đ")
    
    content = payload.get("content", "")
    match = re.search(r"TVT\s*([0-9]{9,11})", content, re.IGNORECASE)
    
    if match:
        phone = match.group(1)
        print(f"✅ Khách hàng: {phone} đã thanh toán thành công!")
        # Kích hoạt gửi Email Resend hoặc Telegram bot tại đây
        return {"success": True, "phone": phone, "status": "DELIVERED"}
    
    return {"success": True, "status": "IGNORED_UNMATCHED_SYNTAX"}

if __name__ == "__main__":
    import uvicorn
    print("🚀 Khởi chạy SePay Webhook Server trên cổng 8005...")
    uvicorn.run(app, host="0.0.0.0", port=8005)
