#!/usr/bin/env python3
"""
⚡ SEPAY WEBHOOK RECEIVER & AUTO-DELIVERY (FASTAPI)
Nhận webhook đối soát giao dịch từ SePay, tra cứu lead theo SĐT trong bảng
`leads` (Supabase) và tự động gửi email bàn giao qua Resend.
"""
from fastapi import FastAPI, Request, HTTPException, Header
from dotenv import load_dotenv
import os
import re
import requests

load_dotenv()  # đọc file .env cùng cấp (hoặc do docker-compose env_file nạp sẵn)

app = FastAPI(title="SePay Auto-Delivery Webhook Gateway")

API_KEY = os.environ["SEPAY_WEBHOOK_TOKEN"]  # bắt buộc set qua biến môi trường, không hard-code

SUPABASE_URL = os.getenv("SUPABASE_URL", "")
SUPABASE_SERVICE_ROLE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "")

RESEND_API_KEY = os.getenv("RESEND_API_KEY", "")
RESEND_FROM_EMAIL = os.getenv("RESEND_FROM_EMAIL", "onboarding@resend.dev")
RESEND_FROM_NAME = os.getenv("RESEND_FROM_NAME", "Customer Success Team")

BRAND_NAME = os.getenv("BRAND_NAME", "toilatung.com")
PRODUCT_NAME = os.getenv("PRODUCT_NAME", "Sản phẩm của bạn")
PRODUCT_DOWNLOAD_URL = os.getenv("PRODUCT_DOWNLOAD_URL", "")
SUPPORT_ZALO = os.getenv("SUPPORT_ZALO", "")  # chỉ số, vd: 0972613555

TEMPLATE_PATH = os.path.join(os.path.dirname(__file__), "..", "resend", "templates", "order_delivery.html")


def find_lead_by_phone(phone: str):
    """Tra bảng `leads` theo SĐT, lấy bản ghi cập nhật gần nhất."""
    if not SUPABASE_URL or not SUPABASE_SERVICE_ROLE_KEY:
        print("⚠️ SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY chưa cấu hình — không thể tra lead.")
        return None

    headers = {
        "apikey": SUPABASE_SERVICE_ROLE_KEY,
        "Authorization": f"Bearer {SUPABASE_SERVICE_ROLE_KEY}",
    }
    params = {"phone": f"eq.{phone}", "order": "updated_at.desc", "limit": 1}
    resp = requests.get(f"{SUPABASE_URL}/rest/v1/leads", headers=headers, params=params, timeout=10)
    if resp.status_code == 200 and resp.json():
        return resp.json()[0]
    return None


def send_delivery_email(to_email: str, customer_name: str, order_code: str, amount: int):
    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        html = f.read()

    context = {
        "customer_name": customer_name or "bạn",
        "brand_name": BRAND_NAME,
        "product_name": PRODUCT_NAME,
        "download_url": PRODUCT_DOWNLOAD_URL,
        "order_code": order_code,
        "amount_formatted": f"{amount:,}".replace(",", "."),
        "support_zalo": SUPPORT_ZALO,
        "support_zalo_display": " ".join([SUPPORT_ZALO[i:i + 4] for i in range(0, len(SUPPORT_ZALO), 4)]) if SUPPORT_ZALO else "",
    }
    for key, value in context.items():
        html = html.replace(f"{{{{{key}}}}}", str(value))

    if not RESEND_API_KEY:
        print(f"⚠️ RESEND_API_KEY chưa cấu hình — mô phỏng gửi email bàn giao tới {to_email}.")
        return {"status": "simulated"}

    resp = requests.post(
        "https://api.resend.com/emails",
        headers={"Authorization": f"Bearer {RESEND_API_KEY}", "Content-Type": "application/json"},
        json={
            "from": f"{RESEND_FROM_NAME} <{RESEND_FROM_EMAIL}>",
            "to": [to_email],
            "subject": f"[Bàn Giao] {PRODUCT_NAME} của bạn",
            "html": html,
        },
        timeout=10,
    )
    return resp.json() if resp.status_code in (200, 201) else {"error": resp.text}


@app.post("/api/sepay/webhook")
async def sepay_webhook(request: Request, authorization: str = Header(None)):
    if authorization != f"Bearer {API_KEY}":
        raise HTTPException(status_code=401, detail="invalid webhook token")

    payload = await request.json()
    amount = payload.get("transferAmount", 0)
    print(f"📩 Nhận giao dịch từ SePay: {payload.get('gateway')} - {amount:,}đ")

    content = payload.get("content", "")
    match = re.search(r"TVT\s*([0-9]{9,11})", content, re.IGNORECASE)

    if not match:
        return {"success": True, "status": "IGNORED_UNMATCHED_SYNTAX"}

    phone = match.group(1)
    lead = find_lead_by_phone(phone)

    if not lead or not lead.get("email"):
        print(f"⚠️ {phone} đã chuyển khoản nhưng chưa có lead/email đăng ký — cần đối soát thủ công.")
        return {"success": True, "phone": phone, "status": "PAID_NO_EMAIL_ON_FILE"}

    send_delivery_email(lead["email"], lead.get("name", ""), content.strip(), amount)
    print(f"✅ Khách hàng {phone} ({lead['email']}) đã thanh toán và nhận email bàn giao.")
    return {"success": True, "phone": phone, "email": lead["email"], "status": "DELIVERED"}


if __name__ == "__main__":
    import uvicorn
    print("🚀 Khởi chạy SePay Webhook Server trên cổng 8005...")
    uvicorn.run(app, host="0.0.0.0", port=8005)
