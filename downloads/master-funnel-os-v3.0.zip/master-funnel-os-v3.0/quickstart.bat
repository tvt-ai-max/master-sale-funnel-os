@echo off
chcp 65001 >nul
cls
echo ================================================================
echo   🚀 ENTERPRISE MASTER FUNNEL OS v3.0 — 1-CLICK LAUNCHER
echo   Bản quyền: toilatung.com & TVT Agency
echo   Hotline/Zalo: 0972 613 555 ^| Email: contact@toilatung.com
echo ================================================================
echo.
echo   [1] Mở trang Sale Page bán hàng trên Trình duyệt
echo   [2] Khởi chạy Hermes AI Operator CLI (Trợ lý AI tự trị)
echo   [3] Khởi động Cụm Tự Động Hóa Docker (n8n + Postgres + Redis)
echo   [4] Kiểm tra toàn bộ file hệ thống
echo   [0] Thoát
echo.
echo ================================================================
set /p choice="👉 Hãy nhập lựa chọn của bạn [0-4]: "

if "%choice%"=="1" (
    echo Đang mở trang Sale Page...
    start templates\landing-page-template.html
    exit /b
)

if "%choice%"=="2" (
    cd hermes-agent
    if not exist venv (
        echo Đang tạo môi trường ảo Python...
        python -m venv venv
        call venv\Scripts\activate.bat
        pip install -r requirements.txt
    ) else (
        call venv\Scripts\activate.bat
    )
    python run_agent.py
    pause
    exit /b
)

if "%choice%"=="3" (
    cd infrastructure\docker
    docker compose up -d
    echo Truy cập n8n tại: http://localhost:5678
    pause
    exit /b
)

if "%choice%"=="4" (
    python -c "import os; count=sum(len(f) for _,_,f in os.walk('.')); print('Tổng số file: ', count)"
    pause
    exit /b
)

if "%choice%"=="0" (
    echo Tạm biệt!
    exit /b
)
