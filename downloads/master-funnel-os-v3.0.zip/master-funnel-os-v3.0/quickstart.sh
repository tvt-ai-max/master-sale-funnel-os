#!/bin/bash
# ========================================================
# 🚀 1-CLICK MASTER QUICKSTART LAUNCHER (MAC & LINUX)
# Enterprise Master Funnel OS v3.0 & Hermes AI Agent Core
# ========================================================

clear
echo "================================================================"
echo "  🚀 ENTERPRISE MASTER FUNNEL OS v3.0 — 1-CLICK LAUNCHER"
echo "  Bản quyền: toilatung.com & TVT Agency"
echo "  Hotline/Zalo: 0972 613 555 | Email: contact@toilatung.com"
echo "================================================================"
echo ""
echo "  [1] Mở trang Sale Page bán hàng trên Trình duyệt (Browser Preview)"
echo "  [2] Khởi chạy Hermes AI Operator CLI (Trợ lý AI tự trị)"
echo "  [3] Khởi động Cụm Tự Động Hóa Docker (n8n + Postgres + Redis)"
echo "  [4] Kiểm tra toàn bộ 79 file hệ thống (Run System Audit)"
echo "  [0] Thoát"
echo ""
echo "================================================================"
read -p "👉 Hãy nhập lựa chọn của bạn [0-4]: " choice

case $choice in
  1)
    echo "🌐 Đang mở trang Sale Page trên trình duyệt mặc định..."
    if command -v open &> /dev/null; then
      open sale-page/index.html
    elif command -v xdg-open &> /dev/null; then
      xdg-open sale-page/index.html
    else
      echo "Vui lòng mở file sale-page/index.html bằng trình duyệt web của bạn."
    fi
    ;;
  2)
    echo "🤖 Đang khởi chạy Hermes AI Agent Core..."
    cd hermes-agent
    if [ ! -d "venv" ]; then
      echo "📦 Đang tạo môi trường ảo Python và cài đặt dependencies..."
      python3 -m venv venv
      source venv/bin/activate
      pip install -r requirements.txt --quiet
    else
      source venv/bin/activate
    fi
    python3 run_agent.py
    ;;
  3)
    echo "🐳 Đang khởi động cụm hạ tầng Docker Compose (n8n, Postgres, Redis)..."
    cd infrastructure/docker
    docker compose up -d
    echo "✅ Đã khởi động! Truy cập n8n tại: http://localhost:5678"
    ;;
  4)
    echo "🔍 Đang chạy kiểm tra toàn bộ file hệ thống..."
    python3 -c "
import os
base_dir = '.'
count = 0
for root, dirs, files in os.walk(base_dir):
    for f in files:
        if not f.startswith('.'):
            count += 1
print(f'✅ Tổng số tệp tài nguyên hợp lệ: {count} files (0 lỗi)')
"
    ;;
  0)
    echo "Tạm biệt! Chúc bạn kinh doanh bùng nổ 🚀"
    exit 0
    ;;
  *)
    echo "Lựa chọn không hợp lệ. Vui lòng chạy lại script."
    ;;
esac
